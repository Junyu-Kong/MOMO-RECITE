const mongoose = require('mongoose');

const dictionarySchema = new mongoose.Schema({
  name: { type: String, unique: true, required: true },
  words: [{
    // list of words contained in this dictionary
    type: mongoose.Schema.Types.ObjectId, ref: 'Word' 
  }],
  creator: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  public: { type: Boolean, default: true }
});

const Dictionary = mongoose.model('Dictionary', dictionarySchema);

module.exports = Dictionary;