const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  dailyLearnCount: { type: Number, default: 10 },
  dailyReviewCount: { type: Number, default: 10 },
  isLoggedin: { type: Boolean, default: false},
  lastLogin: { type: Date, default: Date.now },
  numWordsLearnedToday: { type: Number, default: 0},
  numWordsReviewedToday: { type: Number, default: 0},
  
  recitingDictionary: {type: mongoose.Schema.Types.ObjectId, ref: 'Dictionary'},

  words: [{
    // list of words that have been studied by this user
    word_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Word' },
    dictionary_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Dictionary' },
    familiarity_weight: { type: Number, default: 0.0 }
  }],
  dictionaries: [{
    // list of dictionaries owned by this user
    type: mongoose.Schema.Types.ObjectId, ref: 'Dictionary' 
  }]
});

const User = mongoose.model('User', userSchema);

module.exports = User;
