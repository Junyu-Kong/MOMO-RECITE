const { authJwt } = require("../middlewares");
const controller = require("../controllers/user_setting.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "Origin, Content-Type, Accept"
        );
        next();
    });

    app.post("/api/user/dailyLearnCount", [authJwt.verifyToken], controller.updateDailyLearnCount);

    app.post("/api/user/dailyReviewCount", [authJwt.verifyToken], controller.updateDailyReviewCount);

    app.post("/api/user/recitingDictionary", [authJwt.verifyToken], controller.updateRecitingDictionary);

    app.get("/api/user/currentDictionary", [authJwt.verifyToken], controller.getCurrentDict);

    app.get("/api/user/allAccessibleDictionary", [authJwt.verifyToken], controller.allAccessibleDictionary);

    app.post("/api/user/wordsBasedOnFam", [authJwt.verifyToken], controller.getWordsBasedOnFam);

    app.post("/api/user/getWordsFromDictionary", [authJwt.verifyToken], controller.getWordsFromDictionary);

    app.post("/upload", [authJwt.verifyToken], controller.uploadDictionary);

    app.post("/api/user/createDictionary", [authJwt.verifyToken], controller.createDictionary);
};