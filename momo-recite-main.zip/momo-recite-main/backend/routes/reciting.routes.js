const { authJwt } = require("../middlewares");
const controller = require("../controllers/reciting.controller");

module.exports = function (app) {
    app.use(function (req, res, next) {
        res.header(
            "Access-Control-Allow-Headers",
            "Origin, Content-Type, Accept"
        );
        next();
    });

    app.post("/api/recite/updateLearn", [authJwt.verifyToken], controller.updateLearn);

    app.post("/api/recite/updateReview", [authJwt.verifyToken], controller.updateReview);

    app.get("/api/recite/getDailyLearnCount", [authJwt.verifyToken], controller.getDailyLearnCount);

    app.get("/api/recite/getDailyReviewCount", [authJwt.verifyToken], controller.getDailyReviewCount);

    app.get("/api/recite/getNumLearn", [authJwt.verifyToken], controller.getNumLearn);

    app.get("/api/recite/getNumReview", [authJwt.verifyToken], controller.getNumReview);

    app.post("/api/recite/getLearnList", [authJwt.verifyToken], controller.getLearnList);

    app.post("/api/recite/getReviewList", [authJwt.verifyToken], controller.getReviewList);

    app.post("/api/recite/getWordlist", [authJwt.verifyToken], controller.returnWordlist);
};