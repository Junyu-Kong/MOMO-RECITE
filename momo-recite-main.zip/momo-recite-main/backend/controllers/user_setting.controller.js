const User = require('../models/User');
const Word = require('../models/Word');
const {
    setUserRecitingDictionary,
    user_setdailyLearnCount,
    user_setdailyReviewCount,
    listAllDictionaries,
    getUserRecitingDictionary,
    getAllWordinDict
} = require("../helpers/Helper-edit-userWordDict");
const { generateDictionaryFromFile } = require("../helpers/Helper-creation-loginout");
const fs = require('fs');
const path = require('path');


const updateDailyLearnCount = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    const newDailyLearnCount = req.body.dailyLearnCount;

    user_setdailyLearnCount(userId, newDailyLearnCount)
        .then(() => {
            res.status(200).send({ message: "Daily learn count updated successfully." });
            console.log("Daily learn count updated successfully.")
        })
        .catch((err) => {
            console.log(err.message);
            res.status(500).json({ message: err.message });
        });
};

const updateDailyReviewCount = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    const newDailyReviewCount = req.body.dailyReviewCount;

    user_setdailyReviewCount(userId, newDailyReviewCount)
        .then(() => {
            res.status(200).send({ message: "Daily review count updated successfully." });
            console.log("Daily review count updated successfully.")
        })
        .catch((err) => {
            console.log(err.message);
            res.status(500).json({ message: err.message });
        });
};

const updateRecitingDictionary = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    const newRecitingDictionary = req.body.recitingDictionary;
    console.log(newRecitingDictionary)
    console.log("---------------------------------------")
    setUserRecitingDictionary(userId, newRecitingDictionary)
        .then(() => {
            res.status(200).send({ message: "New reciting dictionary updated successfully." });
            console.log("New reciting dictionary updated successfully.")
        })
        .catch((err) => {
            console.log(err.message);
            res.status(500).json({ message: err.message });
        });
};

const getCurrentDict = async (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request
    try {
        const cur_dict = await getUserRecitingDictionary(userId);
        // console.log(cur_dict);
        res.json({ cur_dict }); // need to retrive in frontend like this : response.data.cur_dict
    } catch (err) {
        console.log(err.message);
        res.status(500).json({ message: err.message });
    }
};

const allAccessibleDictionary = async (req, res) => {
    try {
        const userId = req.userId; // Assuming the userId is available in the request
        const dictionaries = await listAllDictionaries(userId);
        // console.log(dictionaries);
        res.json({ dictionaries });
    } catch (err) {
        console.log(err.message);
        res.status(500).json({ message: err.message });
    }
};

const getWordsBasedOnFam = async (req, res) => {
    try {
        const userId = req.userId; // Assuming the userId is available in the request

        // Find the user by userId and populate the 'words' field
        const user = await User.findById(userId).populate('words.word_id');

        // Separate words based on familiarity
        const highFamiliarityWords = [];
        const mediumFamiliarityWords = [];
        const lowFamiliarityWords = [];

        user.words.forEach((word) => {
            const familiarity = word.familiarity_weight;

            if (familiarity > 0.7) {
                highFamiliarityWords.push(word.word_id);
            } else if (familiarity > 0.3) {
                mediumFamiliarityWords.push(word.word_id);
            } else {
                lowFamiliarityWords.push(word.word_id);
            }
        });

        // Populate the word objects in the arrays
        const populateOptions = { path: 'word_id', model: 'Word' };
        await Promise.all([
            Word.populate(highFamiliarityWords, populateOptions),
            Word.populate(mediumFamiliarityWords, populateOptions),
            Word.populate(lowFamiliarityWords, populateOptions),
        ]);

        // Return the arrays of word objects
        res.status(200).json({
            highFamiliarityWords,
            mediumFamiliarityWords,
            lowFamiliarityWords
        });
    } catch (error) {
        console.log(err.message);
        res.status(500).json({ message: err.message });
    }
};

const getWordsFromDictionary = async (req, res) => {
    try {
        const dict_id = req.body.dict_id; // Assuming the userId is available in the request
        const words = await getAllWordinDict(dict_id);

        res.status(200).send(words);
    } catch (err) {
        console.log(err.message);
        res.status(500).json({ message: err.message });
    }
};

const uploadDictionary = async (req, res) => {
    try {

        if (!req.files || Object.keys(req.files).length === 0) {
            return res.status(400).send('No files were uploaded.');
          }

        let dictionary = req.files.file;
        dictionary.mv(path.join(__dirname, '..', 'tmp', dictionary.name), function (err) {
            if (err) {
                console.log(err);
                return res.status(500).send(err);
            }  
            res.status(200).send({ value: req.files.file.name });
        });

    } catch (err) {
        console.log(err.message);
        res.status(500).json({ message: err.message });
    }
};

const createDictionary = async (req, res) => {
    try {
        var dictionary = path.join(__dirname, '..', 'tmp', req.body.filename);
        let dict_id = await generateDictionaryFromFile(dictionary, req.userId, req.body.dict_name, req.body.public);
        if (dict_id) {
            console.log("Deleting temporary file received...");
            fs.unlinkSync(dictionary);
            res.status(200).send({ message: "Dictionary has been created." });
        }

    } catch (err) {
        console.log(err);
        console.log("Deleting temporary file received...");
        fs.unlinkSync(dictionary);
        res.status(500).json({ message: err.message });
    }
};


module.exports = {
    updateDailyLearnCount,
    updateDailyReviewCount,
    updateRecitingDictionary,
    getCurrentDict,
    allAccessibleDictionary,
    getWordsBasedOnFam,
    getWordsFromDictionary,
    uploadDictionary,
    createDictionary
};
