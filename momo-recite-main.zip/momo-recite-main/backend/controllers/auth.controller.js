const config = require("../helpers/auth.config");
const User = require('../models/User');

var jwt = require("jsonwebtoken");
var bcrypt = require("bcryptjs");

exports.signup = (req, res) => {
    const user = new User({
        username: req.body.username,
        password: bcrypt.hashSync(req.body.password, 8),
    });

    user.save()
        .then(() => {
            res.send({ message: "User was registered successfully!" });
            console.log("User was registered successfully!");
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err)
        });
};

exports.signin = (req, res) => {
    User.findOne({
        username: req.body.username,
    })
        .exec((err, user) => {
            if (err) {
                res.status(500).send({ message: err });
                return;
            }

            if (!user) {
                res.status(404).send({ message: "User not found." });
                console.log("User Not found.");
                return;
            }

            var passwordIsValid = bcrypt.compareSync(
                req.body.password,
                user.password
            );

            if (!passwordIsValid) {
                res.status(401).send({ message: "Invalid Password! / Unauthorized!" });
                console.log("Invalid Password!");
                return;
            }

            var token = jwt.sign({ id: user._id }, config.secret, {
                expiresIn: 86400, // 24 hours
            });

            req.session.token = token;
            res.status(200).send({
                id: user._id,
                username: user.username,
                message: "User successfully logged in!"
            });

            const lastLoginDate = new Date(user.lastLogin);
            const currentDate = new Date();
            const isSameDay = 
                lastLoginDate.getDate() === currentDate.getDate() &&
                lastLoginDate.getMonth() === currentDate.getMonth() &&
                lastLoginDate.getFullYear() === currentDate.getFullYear();
            
            if(!isSameDay){
                user.numWordsLearnedToday = 0;
                user.numWordsReviewedToday = 0;
            }
            
            user.isLoggedin = true;
            user.lastLogin = Date.now();
            user.save()
            .then(() => {
                console.log("User successfully logged in!");
            })
            .catch((err) => {
                console.log(err);
            })
        });
};

exports.signout = async (req, res) => {
    try {
        User.findOne({
            _id: req.userId,
        }).exec((err, user) => {
            if (err) {
                res.status(500).send({ message: err });
                return;
            }

            if (!user) {
                res.status(404).send({ message: "User not found." });
                console.log("User Not found.");
                return;
            }

            user.isLoggedin = false;
            user.save();
        })

        if (req.session) {
            req.session = null;
            res.status(200).send({ message: "You've been signed out!" });
            console.log("User successfully signed out!");
            return;
        } else {
            res.status(400).send({ message: "Session not found." });
            console.error("Session not found.");
            return;
        }
    } catch (err) {
        res.status(500).send({ message: err });
        console.log(err);
    }
};

exports.verifyLogin = (req, res) => {
    try {
        User.findOne({
            _id: req.userId,
        }).exec((err, user) => {
            if (err) {
                res.status(500).send({ message: err });
                return;
            }

            if (!user) {
                res.status(404).send({ message: "User not found." });
                console.log("User Not found.");
                return;
            }

            const lastLoginDate = new Date(user.lastLogin);
            const currentDate = new Date();
            const isSameDay = 
                lastLoginDate.getDate() === currentDate.getDate() &&
                lastLoginDate.getMonth() === currentDate.getMonth() &&
                lastLoginDate.getFullYear() === currentDate.getFullYear();
            
            if(!isSameDay){
                user.numWordsLearnedToday = 0;
                user.numWordsReviewedToday = 0;
                user.lastLogin = Date.now();
                user.save()
            }

            res.status(200).send({ message: "isLoggedIn", username: user.username });
        })
        return;
    } catch (err) {
        res.status(500).send({ message: err });
        console.log(err);
    }
};