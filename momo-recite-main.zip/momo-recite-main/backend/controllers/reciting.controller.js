const helper = require('../helpers/Helper-edit-userWordDict');
const helper2 = require('../helpers/Helper-user-word');

const updateLearn = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request
    // these two might change depending on frontend!!!
    const curChoice = req.body.curChoice;
    const curWord = req.body.curWord;
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    helper.recordLearnWord(userId, curWord, curChoice)
        .then(() => {
            res.status(200).send({ message: "a new word learned recorded!" });
            // console.log("a new word learned recorded!");
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const updateReview = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    // these two might change depending on frontend!!!
    const curChoice = req.body.curChoice;
    const curWord = req.body.curWord;
    // ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    helper.recordReviewWord(userId, curWord, curChoice)
        .then(() => {
            res.status(200).send({ message: "an old word reviewed recorded!" });
            // console.log("an old word reviewed recorded!");
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getDailyLearnCount = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    helper.user_dailyLearnCount(userId)
        .then((count) => {
            res.status(200).send({ value: count });
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getDailyReviewCount = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    helper.user_dailyReviewCount(userId)
        .then((count) => {
            res.status(200).send({ value: count });
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getNumLearn = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    helper.user_numWordsLearnedToday(userId)
        .then((count) => {
            helper.user_dailyLearnCount(userId)
                res.status(200).send({ value: count });
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getNumReview = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request

    helper.user_numWordsReviewedToday(userId)
        .then((count) => {
            res.status(200).send({ value: count });
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getLearnList = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request
    const numToRetrieve = req.body.learnToRetrieve;

    helper2.newWordListforUser(userId, { numWordsToReturn: numToRetrieve })
        .then((list) => {
            res.status(200).send({ value: list });
            // console.log(`User acquired new learn list! ${list}`);
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

const getReviewList = (req, res) => {
    const userId = req.userId; // Assuming the userId is available in the request
    const numToRetrieve = req.body.reviewToRetrieve;

    helper2.reviewWordListforUser(userId, { numWordsToReturn: numToRetrieve })
        .then((list) => {
            res.status(200).send({ value: list });
            // console.log(`User acquired new review list! ${list}`);
        })
        .catch((err) => {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        });
};

async function setRetrieveNumbers(userId, res) {
    const RETRIEVE_MIN = 4;
    const RETRIEVE_MAX = 20;

    try {
        var learnToRetrieve = await (async () => {
            const dailyLearnCount = await helper.user_dailyLearnCount(userId);
            const value = await helper.user_numWordsLearnedToday(userId);
            const numLearnLeft = dailyLearnCount - value;

            let learnToRetrieve = Math.floor(dailyLearnCount / 4);
            learnToRetrieve = RETRIEVE_MAX < learnToRetrieve ? RETRIEVE_MAX : learnToRetrieve;

            const RETRIEVE_MIN_LEARN = dailyLearnCount < RETRIEVE_MIN ? dailyLearnCount : RETRIEVE_MIN;
            learnToRetrieve = learnToRetrieve < RETRIEVE_MIN_LEARN ? RETRIEVE_MIN_LEARN : learnToRetrieve;
            learnToRetrieve = numLearnLeft < learnToRetrieve ? numLearnLeft : learnToRetrieve;

            if (learnToRetrieve < 0)
                learnToRetrieve = 0;

            return learnToRetrieve;
        })();

        var reviewToRetrieve = await (async () => {
            const dailyReviewCount = await helper.user_dailyReviewCount(userId);
            const value = await helper.user_numWordsReviewedToday(userId);
            const numReviewLeft = dailyReviewCount - value;

            let reviewToRetrieve = Math.floor(dailyReviewCount / 4);
            reviewToRetrieve = RETRIEVE_MAX < reviewToRetrieve ? RETRIEVE_MAX : reviewToRetrieve;
    
            const RETRIEVE_MIN_REVIEW = dailyReviewCount < RETRIEVE_MIN ? dailyReviewCount : RETRIEVE_MIN;
            reviewToRetrieve = reviewToRetrieve < RETRIEVE_MIN_REVIEW ? RETRIEVE_MIN_REVIEW : reviewToRetrieve;
            reviewToRetrieve = numReviewLeft < reviewToRetrieve ? numReviewLeft : reviewToRetrieve;

            if (reviewToRetrieve < 0)
                reviewToRetrieve = 0;

            return reviewToRetrieve;
        })();

        return { learnToRetrieve, reviewToRetrieve };
    } catch (err) {
        res.status(500).send({ message: err });
        console.log(err);
        return;
    }
}

async function getWordlist(userId, { learnToRetrieve, reviewToRetrieve }, res) {
    return new Promise(async (resolve, reject) => {
        try {
            var tempWordlist = [];
            if (learnToRetrieve) {
                const learnWords = await (async () => {
                    let returnedWords = await helper2.newWordListforUser(userId, { numWordsToReturn: learnToRetrieve });

                    for (let word of returnedWords) {
                        word.review = 0;
                    }

                    return returnedWords;
                })();

                tempWordlist.push(...learnWords);
            }

            if (reviewToRetrieve) {
                const reviewWords = await (async () => {
                    let returnedWords = await helper2.reviewWordListforUser(userId, { numWordsToReturn: reviewToRetrieve });

                    for (let word of returnedWords) {
                        word.review = 1;
                    }

                    return returnedWords;
                })();

                tempWordlist.push(...reviewWords);
            }

            // shuffles wordlist
            function shuffle(wordlist) {
                for (let index = wordlist.length - 1; index > 0; index--) {
                    let randIndex = Math.floor(Math.random() * (index + 1));
                    let temp = wordlist[index];
                    wordlist[index] = wordlist[randIndex];
                    wordlist[randIndex] = temp;
                }
            };
            shuffle(tempWordlist);

            resolve(tempWordlist);
        } catch (err) {
            res.status(500).send({ message: err });
            console.log(err);
            return;
        }
    });
}

const returnWordlist = async (req, res) => {
    try {
        const userId = req.userId; // Assuming the userId is available in the request
        let { learnToRetrieve, reviewToRetrieve } = await setRetrieveNumbers(userId, res);
        if (!learnToRetrieve && !reviewToRetrieve) {
            res.status(204).send({ message: "No words left to learn for the day." });
            return;
        }

        if (req.body.numWordsLeft) {
            if (req.body.numEachClass[0] > learnToRetrieve || req.body.numEachClass[1] > reviewToRetrieve) {
                res.status(205).send({ message: "We need to refresh the page." });
                return;
            }

            res.status(200).send({ message: "There are words left." });
            return;
        }

        var tempWordlist = await getWordlist(userId, { learnToRetrieve, reviewToRetrieve }, res);

        res.status(200).send({ value: tempWordlist });
    } catch (err) {
        res.status(500).send({ message: err });
        console.log(err);
        return;
    }
}

module.exports = {
    updateLearn,
    updateReview,
    getDailyLearnCount,
    getDailyReviewCount,
    getNumLearn,
    getNumReview,
    getLearnList,
    getReviewList,
    returnWordlist
};