const express = require('express');
const cors = require('cors');
const cookieSession = require("cookie-session");
const helper = require('./helpers/Helper-creation-loginout');
const mongoose = require('mongoose');
const fileUpload = require('express-fileupload');

const app = express();

const corsOptions = {
    origin: 'http://localhost:3000', // Replace with the origin of your frontend application
    credentials: true,
};
app.use(cors(corsOptions));

// parse requests of content-type - application/json
app.use(express.json());

// parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

app.use(fileUpload());

app.use(
    cookieSession({
        name: "felix-session",
        secret: "COOKIE_SECRET", // should use as secret environment variable
        httpOnly: true
    })
);

// connect to DB
// please set REMOTE_DATABASE_NAME to working DB
const REMOTE_DATABASE_NAME = 'test';
const db_settings = require('./helpers/db-settings');
const uri = db_settings.setRemoteDatabase(REMOTE_DATABASE_NAME);

const startServer = async () => {
    try {
        await mongoose.connect(uri).then(() =>
            console.log('MongoDB connected!')).catch(err => console.log(err));
    } catch (error) {
        console.error('Error connecting to MongoDB:', error);
    }

    // routes
    require("./routes/auth.routes")(app);
    require("./routes/user_setting.routes")(app);
    require("./routes/reciting.routes")(app);

    // simple route
    app.get("/", (req, res) => {
        res.json({ message: "Welcome to MOMO Recite !." });
    });

    // Start the server
    app.listen(5000, () => {
        console.log('Server is running on port 5000');
    });
};

startServer();
