const mongoose = require('mongoose');
const User = require('../models/User');
const Dictionary = require('../models/Dictionary');
const Word = require('../models/Word.js');
//Assuming, they are in the same directory as test script.
//add ./models/... if run from root directory.
const REMOTE_DATABASE_NAME = 'test';
const db_settings = require('./db-settings');
const Constants = require('./wordConstants.js');
const uri = db_settings.setRemoteDatabase(REMOTE_DATABASE_NAME);


/**
 * Add a wordId to a dictionary with dictionaryId. 
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @returns {Promise <void>} after saving succeeds. 
 * @throws {Error} if no dictionary with this id exists.
 * @throws {Error} if the word with this id already exists in the dictionary.
 * @throws {Error} if the word with this id doesn't exist in word collection.
 */
async function addWordToDictionary(dictionaryId, wordId) {
    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error('The dictionary does not exist!');
    }

    

    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`Word with id ${wordId} does not exist!`);
    }
    if(dictionary.words.includes(wordId)){
        throw new Error(`Word ${word.originalWord} already exists in dictionary!`);
    }
    dictionary.words.push(wordId);
    await dictionary.save();
}

/**
 * replace the Words in a dictionary through a list of word id's.
 * Duplicated id's in the list will be removed without any warning.
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @param {mongoose.Types.ObjectId[]} newWordList
 * @returns {Promise<void>} after the words have been updated.
 * @throws {Error} if the dictionary with this id doesn't exit.
 * @throws {Error} if any of the words in the list doesn't exist in words collection.
 *  
 */
async function replaceWordsInDictionary(dictionaryId, newWordList) {
    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error('The dictionary does not exist!');
    }

    newWordList = [...new Set(newWordList)]; //use [...] to convert back to array.
    await Promise.all(newWordList.map(async (wordId) => {
        const word = await Word.findById(wordId);
        if (!word) {
            throw new Error(`Word with id ${wordId} does not exist!`);
        }
    }));

    dictionary.words = newWordList;
    await dictionary.save();

}

/**
 * remove a word id from a dictionary. It doesn't remove word in the collection.
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @returns {Promise <void>} when the removal finishes. 
 * @throws {Error} if no dictionary with this id exists.
 * @throws {Error} if the word with this id doesn't exist in word collection.
 * Does nothing if, the word is in the collection, but not in the dictionary. 
 */
async function removeWordinDictionary(dictionaryId, wordId) {
    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error('The dictionary does not exist!');
    }

    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`Word with id ${wordId} does not exist!`);
    }

    dictionary.words.pull(wordId);

    await dictionary.save();

    if (!dictionary.words.includes(wordId)) {
        console.log(`Warning: trying to delete a non-exist word ${word.originalWord} from dictionary ${dictionary.name}`);
    }
}

/**
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @param {String} newName - the new name for the dictionary.
 * @returns {Promise <void>} when the rename finishes.
 * @throws {Error} if the dictionary id doesn't exist. 
 */
async function renameDictionary(dictionaryId, newName) {
    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error(`The dictionary ${dictionaryId} does not exist!`);
    }
    dictionary.name = newName;
    await dictionary.save();
}

/**
 * 
 * @param {mongoose.Types.ObjectId} wordId 
 * @param {String} newDescription 
 * @returns {Promise <void>} when the description is udpated.
 * @throws {Error} when the word Id doesn't exist in words collection.
 */
async function changeDescriptionofWord(wordId, newDescription) {
    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`Word with id ${wordId} does not exist!`);
    }

    word.description = newDescription;
    await word.save();
}

/**
 * Delete a word with an id. 
 * 
 * @param {mongoose.Types.ObjectId} wordId
 * @returns {Promise <void>} after the word has been deleted.
 * @throws {Error} if the word with this id does not exist in collection.
 * @logs in console when the delete is finished. 
 */
async function deleteWord(wordId) {
    const result = await Word.findByIdAndDelete(wordId);
    if (!result) {
        throw new Error(`Word with id ${wordId} does not exist!`);
    }

    console.log(`Deleted Word: ${wordId}`);
}

/**
 * Delete a dictionary with an id. It won't update user's dictionary Id list.
 * Use deleteDictioonary_removefromUser, and provide dict id and user id. 
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId
 * @returns {Promise <void>} after the dictionary has been deleted.
 * @throws {Error} if the dictionary with this id does not exist in collection.
 * @logs in console when the delete is finished. 
 */
async function deleteDictionary(dictionaryId) {
    const result = await Dictionary.findByIdAndDelete(dictionaryId);
    if (!result) {
        throw new Error(`Dictionary with id ${dictionaryId} does not exist!`);
    }

    console.log(`Deleted Dictionary with id ${dictionaryId}`);
}

/**
 * Delete a dictionary with an id. It updates user's dictionary Id list.
 * 
 * @param {mongoose.Types.ObjectId} dictionaryId
 * @param {mongoose.Types.ObjectId} userId
 * @returns {Promise <void>} after the dictionary has been deleted, and user has been updated.
 * @throws {Error} if the dictionary with this id does not exist in collection.
 * @throws {Error} if the user does not exist.
 * @logs in console when the delete and removalis finished. 
 */
async function deleteDictionary_removefromUser(dictionaryId, userId) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to delete dictionary from does not exist!');
    }
    //No checking if the dictionary exists!
    user.dictionaries.pull(dictionaryId);

    const result = await Dictionary.findByIdAndDelete(dictionaryId);
    if (!result) {
        throw new Error(`Dictionary with id ${dictionaryId} does not exist!`);
    }

    await user.save();

    console.log(`Removed Dictionary from user with id ${userId}`);
    console.log(`Deleted Dictionary with id ${dictionaryId}`);
}

/**
 * return the a user's dailyLearnCount setting given the userId.
 * @param {mongoose.Types.ObjectId} userId
 * @returns {Number} the current daily Learn Count setting.
 * @throws {Error} if the userId doesn't exist. 
 */
async function user_dailyLearnCount(userId) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to return dailyLearnCount does not exist!');
    }
    return user.dailyLearnCount;
}

async function user_numWordsLearnedToday(userId){
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to return dailyLearnCount does not exist!');
    }
    return user.numWordsLearnedToday;
}


/**
 * set a user's dailyLearnCount setting with userId and given number.
 * @param {mongoose.Types.ObjectId} userId 
 * @param {Number} newdailyLearnCount 
 * @returns {Promise <void>} after dailyLearnCount setting has been updated. 
 * @throws {Error} if the userId doesn't exist.
 * @logs in console about the change. 
 */
async function user_setdailyLearnCount(userId, newdailyLearnCount) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to set dailyLearnCount does not exist!');
    }

    user.dailyLearnCount = newdailyLearnCount;
    await user.save();
    console.log(`Set user: ${user.username} with daily LearnCount: ${newdailyLearnCount}`);
}

/**
 * Set a user's numWordsLearnedToday entry to 0.
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @throws {Error} if user does not exist.
 * @logs in console to indicate the change.
 * Note that, it's written with the assumption that the user would see it.
 */
async function user_ResetwordsLearned(userId){
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to reset dailyLearnCount does not exist!');
    }

    user.numWordsLearnedToday = 0;
    await user.save();
    console.log(`Proceeding ${user.username}'s learn word process to the next day.`);
}

/**
 * return the a user's dailyReviewCount setting given the userId.
 * @param {mongoose.Types.ObjectId} userId
 * @returns {Number} the current daily review Count setting.
 * @throws {Error} if the userId doesn't exist. 
 */
async function user_dailyReviewCount(userId) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} to return dailyReviewCount does not exist!`);
    }
    return user.dailyReviewCount;
}

async function user_numWordsReviewedToday(userId){
    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} to return dailyReviewCount does not exist!`);
    }
    return user.numWordsReviewedToday;
}

/**
 * set a user's dailyReviewCount setting with userId and given number.
 * @param {mongoose.Types.ObjectId} userId 
 * @param {Number} newdailyReviewCount 
 * @returns {Promise <void>} after dailyReviewCount setting has been updated. 
 * @throws {Error} if the userId doesn't exist.
 * @logs in console about the change. 
 */
async function user_setdailyReviewCount(userId, newdailyReviewCount) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to set dailyReviewCount does not exist!');
    }

    user.dailyReviewCount = newdailyReviewCount;
    await user.save();
    console.log(`Set user: ${user.username} with daily ReviewCount: ${newdailyReviewCount}`);
}

/**
 * Set a user's numWordsReviewedToday entry to 0.
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @throws {Error} if user does not exist.
 * @logs in console to indicate the change.
 * Note that, it's written with the assumption that the user would see it.
 */
async function user_ResetwordsReviewed(userId){
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to reset dailyReviewCount does not exist!');
    }

    user.numWordsReviewedToday = 0;
    await user.save();
    console.log(`Proceeding ${user.username}'s review word process to the next day.`);

}

/**
 * !!!WARNING!!! Use recordLearnWord after new word has been shown to a user.
 * recordLearnWord will add word to user and set fam weight. 
 * Add a word to a user given user, word and dictionaryId, and optional famailar weight.
 * You may want to call it when a new word is shown to the user. 
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @param {Number} fam_weight - familiarity weight to be set. Default 0. Optional. 
 * @throws {Error} if the user, word, or dictionary doesn't exist.
 * @throws {Error} if the dictionary doesn't include the word.
 * @returns {Promise <void>} after the addition has been done / addition failed.
 * @logs in console if the addition succeeded or failed. Fails and does nothing if
 * the word already exists in user.words.
 */
async function addWordtoUser(userId, wordId, dictionaryId, fam_weight = 0.0) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error('User to set dailyReviewCount does not exist!');
    }

    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`Can not add word: ${wordId} to user as the word does not exist!`);
    }

    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error(`Can not add dict: ${dictionaryId} to user as the dict does not exist!`);
    }

    if (!dictionary.words.includes(wordId)) {
        throw new Error(`Can not add word to user, as ${word.originalWord} is not in dict ${dictionary.name}`);
    }
    let newWord = {
        word_id: wordId,
        dictionary_id: dictionaryId,
        familiarity_weight: fam_weight
    }

    if (!user.words.some(userWord => userWord.word_id.toString() === wordId.toString())) {
        user.words.addToSet(newWord);
        await user.save();
        console.log(`Added word: ${word.originalWord} to user ${user.username}`);
    } else {
        console.log(`Can not add word: ${word.originalWord} to user ${user.username} as the word already exists!`);
    }

}

/**
 * Delete a Word from user.words. !!!Dangerous!!! It makes the word deleted back to a new word!!!!!
 * Update the famailar weight instead, to avoid words to be choosen to review. 
 * The function is provided when something messed up (as it was when I first tested add words function.)
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @throws {Error} if the user or word doesn't exist. 
 * @warns in console, if the user doesn't have that word.
 */
async function deleteWordfromUser(userId, wordId) {

    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} to set dailyReviewCount does not exist!`);
    }

    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`Word ${wordId} does not exist!`);
    }

    const wordExists = user.words.some(userWord => userWord.word_id.toString() === wordId.toString());
    if (!wordExists) {
        console.log(`Warning: Trying to delete word ${word.originalWord} from user ${user.username},` +
            ` But the user does not have that word.`);
    }

    user.words.pull({ word_id: wordId });
    await user.save();
    console.log(`Deleted word: ${word.originalWord} from user ${user.username}`)
}



/**
 * Record a user's newly learned word by: 
 * Adding the word to user with fam weight decided by choice, add 1 to today's learn word count
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @param {String} choice - select from "remember", "forgot", "somewhatRemember"
 * @param {mongoose.Types.ObjectId} dictionaryId - OPTIONAL, defaults to user's current reciting dict.
 * @returns {Promise <void>} after the word has been recorded.
 * @throws {Error} if: user or word or dictionary (if specified) doesn't exist, 
 * or, if not given dictionaryId, if user doesn't have a reciting dict set, or, 
 * the word does not exist in dictionary, or the choice is invalid. 
 * @logs in console, about the user, new word, and words learned today of this user.  
 */
async function recordLearnWord(userId, wordId, choice, dictionaryId = null) {

    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} to record numWords learned does not exist!`);
    }

    let dictionary;
    if (dictionaryId === null) {
        if (!user.recitingDictionary) {
            throw new Error(`User ${user.username} does not have a current Dictionary set,`
                + ` And no dictionaryId is provided to recordLearnWord`);
        }
        dictionary = await Dictionary.findById(user.recitingDictionary);
    } else {
        dictionary = await Dictionary.findById(dictionaryId);
    }

    if (!dictionary) {
        throw new Error(`Dictionary ${dictionaryId} does not exist!`);
    }

    const word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`The word: ${wordId} does not exist!`);
    }

    if (!dictionary.words.includes(wordId)) {
        throw new Error(`The word: ${word.originalWord} does not exist in dict ${dictionary.name}`);
    }

    let wordFamWeight = 0;
    switch (choice) {
        case "remember":
            wordFamWeight += Constants.FIRST_REMEMBER_WEIGHT;
            break;
        case "forgot":
            wordFamWeight += Constants.FIRST_TIME_FORGOT_WEIGHT;
            break;
        case "somewhatRemember":
            wordFamWeight += Constants.FIRST_TIME_SOMEWHAT_WEIGHT;
            break;
        default:
            throw new Error(`Invalid choice ${choice} passed to recordLearnWord` +
                `Select from: "remember", "forgot", or "somewhatRemember"`);
    }

    await addWordtoUser(userId, wordId, dictionary._id, wordFamWeight);

    user.numWordsLearnedToday += 1;
    await user.save();

    console.log(`User ${user.username} newly learned ${word.originalWord},` +
        ` he has learned ${user.numWordsLearnedToday} today`);
        /*
    console.log(`Note: Previous message is print even if the add word to user failed.`
    + `Things are good if no error message is print.`);*/
}

/**
 * Record a user's reviewed word by: 
 * Updating the word's fam weight based on choice , add 1 to today's review word count
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {mongoose.Types.ObjectId} wordId 
 * @param {String} choice - select from "remember", "forgot", "somewhatRemember"
 * @returns {Promise <void>} after the word has been updated.
 * @throws {Error} if: user or word doesn't exist, or the user hasn't learned the word yet,
 *  or the choice is invalid. 
 * @logs in console, about the user, reviewed word, and words reviewed today of this user.  
 */
async function recordReviewWord(userId, wordId, choice) {

    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} to record numWords reviewed does not exist!`);
    }

    let word = await Word.findById(wordId);
    if (!word) {
        throw new Error(`The word: ${wordId} does not exist!`);
    }

    //We need to update the user.words. fam weight here...
    const userWord = user.words.find(w => w.word_id.toString() === wordId.toString());

    if (!userWord) {
        throw new Error(`User ${user.username} have not yet learned word ${word.originalWord}`);
    }

    switch (choice) {
        case "remember":
            userWord.familiarity_weight += Constants.REMEMBER_WEIGHT;
            break;
        case "forgot":
            userWord.familiarity_weight += Constants.FORGOT_WEIGHT;
            break;
        case "somewhatRemember":
            userWord.familiarity_weight += Constants.SOMEWHAT_REMEMBER_WEIGHT;
            break;
        default:
            throw new Error(`Invalid choice ${choice} passed to recordReviewWord` +
                `Select from: "remember", "forgot", or "somewhatRemember"`);
    }

    user.numWordsReviewedToday += 1;
    await user.save();
    console.log(`User ${user.username} newly reviewed ${word.originalWord},` +
        ` he has reviewed ${user.numWordsReviewedToday} today`);

}

/**
 * Change a users reciting dictionary by user and dictionaryId.
 * It will change the "default" return word list for newWordList, reviewWordList.
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {mongoose.Types.ObjectId} dictionaryId 
 * @returns {Promise <void>} after the update is done. 
 * @throws {Error} if the user or dictionary does not exist.
 * @logs in console about the update.
 */
async function setUserRecitingDictionary(userId, dictionaryId) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} does not exist!`);
    }

    const dictionary = await Dictionary.findById(dictionaryId);
    if (!dictionary) {
        throw new Error(`Can not set dict: ${dictionaryId} to user as the dict does not exist!`);
    }

    user.recitingDictionary = dictionaryId;

    await user.save();

    console.log(`Set dict ${dictionary.name} as user ${user.username} 's reciting dictionary.`);

}

/**
 * returns the user's current reciting dictionary and name given userId
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @returns {mongoose.Types.ObjectId, String} dictionaryId of the user's currently reciting dict.
 * Format: {id: ..., name: ...}
 * @throws {Error} if the user does not exist, or the user has no current reciting dict set.
 * Or, the user's reciting dict is not in our database. 
 */
async function getUserRecitingDictionary(userId) {
    const user = await User.findById(userId);
    if (!user) {
        throw new Error(`User ${userId} does not exist!`);
    }

    if (!user.recitingDictionary) {
        throw new Error(`User ${userId} has no dictionary set to learn!`);
    }

    const dictionaryId = user.recitingDictionary;
    const dictionary = await Dictionary.findById(dictionaryId);
    if(!dictionary){
        throw new Error(`User ${userId} 's reciting dict ${dictionaryId} does not exist!`);
    }

    return {id: user.recitingDictionary, name: dictionary.name};
}

/**
 * Given a userId, and a STRING of word, return the fam weight of 
 * that word, for that user. 
 * 
 * @param {mongoose.Types.ObjectId} userId - the id of the user. 
 * @param {String} wordString - A STRING!!! 
 * @returns {Number} - the familiarity weight of that word.
 * @throws {Error} if, the user, or word, does not exist, or, 
 * the user does not have that word in their user.words.
 */
async function getFamWeightforUserWord(userId, wordString){
    const user = await User.findById(userId);
    if(!user){
        throw new Error(`User ${userId} does not exist!`);
    }

    const word = await Word.findOne({originalWord: wordString});
    if(!word){
        throw new Error(`The word: ${wordString} does not exist!`);
    }

    const wordExists = user.words.some(userWord => userWord.word_id.toString() === word._id.toString());
    if(!wordExists){
        throw new Error (`The word: ${wordString} does not exist in your word list.`);
    }

    const userWord = user.words.find(userWord => userWord.word_id.toString() === word._id.toString());

    return userWord.familiarity_weight;

}

/**
 * return a list of all dictionary Objects, which that user can access.
 * Format: {dict_id: ... , dict_name: ...}
 * (Note: there can be private dictionaries!) It's not tested though, but should work fine.
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @returns {[mongoose.Types.ObjectId, String]} a list of Dictionary objects that user can access.
 * With format: dict_id: ... dict_name:... 
 */
async function listAllDictionaries(userId){
    const user = await User.findById(userId);
    if(!user){
        throw new Error(`User ${userId} does not exist!`);
    }
    const publicDictionaries = await Dictionary.find({ public:true });
    const publicDictIds = publicDictionaries.map(dict => dict._id.toString());
    const userDictIds = user.dictionaries.map(id => id.toString());
    let combinedDictIds = [...publicDictIds, ...userDictIds];
    let uniqueDictIds = [...new Set(combinedDictIds)];
    uniqueDictIds = uniqueDictIds.map(id => new mongoose.Types.ObjectId(id));
    let dictionaryObjs = [];
    for(let dictId of uniqueDictIds){
        const dict = await Dictionary.findById(dictId).select("_id name");
        if(dict){
            dictionaryObjs.push({dict_id: dict._id, dict_name: dict.name});
        } else {
            throw new Error(`Very rare error in listAlldictoinaries.`);
        }
    }
    return dictionaryObjs;
}

/**
 * Return a list of ALL the word documents in the dictionary.
 * 
 * @param {mongoose.Types.ObjectId} dictId 
 * @returns {Word[]} an array of word documents.
 * @throws {Error} if the dictionary does not exist.
 */
async function getAllWordinDict(dictId){
    const dictionary = await Dictionary.findById(dictId).populate('words');
    if(!dictionary){
        throw new Error(`The dictionary ${dictId} does not exist!`);
    }

    let wordObjs = dictionary.words;
    return wordObjs;
}

module.exports = {
    addWordToDictionary,
    replaceWordsInDictionary,
    removeWordinDictionary,
    renameDictionary,
    changeDescriptionofWord,
    deleteWord,
    deleteDictionary,
    deleteDictionary_removefromUser,
    user_dailyLearnCount,
    user_setdailyLearnCount,
    user_dailyReviewCount,
    user_setdailyReviewCount,
    addWordtoUser,
    recordLearnWord,
    recordReviewWord,
    deleteWordfromUser,
    setUserRecitingDictionary,
    getUserRecitingDictionary,
    getFamWeightforUserWord,
    listAllDictionaries,
    user_numWordsLearnedToday,
    user_numWordsReviewedToday,
    user_ResetwordsLearned,
    user_ResetwordsReviewed,
    getAllWordinDict
};