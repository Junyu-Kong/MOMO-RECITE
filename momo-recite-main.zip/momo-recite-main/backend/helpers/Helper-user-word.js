const mongoose = require('mongoose');
const User = require('../models/User');
const Word = require('../models/Word');
const Dictionary = require('../models/Dictionary');
const Constants = require('./wordConstants.js');

//Shuffle an array. 
function shuffle(array){
	//from stackoverflow, question 2450954
	let currentIndex = array.length, randomIndex;
	//while remaining element to shuffle...
	while(currentIndex != 0){
		randomIndex = Math.floor(Math.random() * currentIndex);
		currentIndex --;

		[array[currentIndex], array[randomIndex]] = 
		[array[randomIndex], array[currentIndex]];
	}
	return array;
}

/**
 * return an array of objects for user to newly learn. (Not in user.words)
 * Format: {id: _id, content:{originalWord:..., description:...}}
 * Optional args: dictionaryId, numWordsToReturn
 * Default to: user.recitingDictionary, and (dailyLearnCount - numWordsLearnedToday)
 * Upper limit is the remaining new words in the dictionary, with the dictionaryId. 
 * Usage: newWordListforUser(userId, {dictionaryId: foo, numWordsToReturn: bar})
 * where both in {} is optional.
 * 
 * @param {mongoose.Types.ObjectId} userId required.
 * @param {mongoose.Types.ObjectId, Number} options dictionaryId, numWordsToReturn
 * @returns {mongoose.Types.ObjectId[]} - list of new word id objects.
 * @throws {Error} if the user doesn't exist, or no dictionaryId specified AND user has no
 * .recitingDictionary set. (Use setUserRecitingDictionary.), or dictionary doesn't exist.
 * @warns in console, if the numWords to return is <= 0, either because user learned enough words,
 * or the numWordsToReturn passed in is negative.
 * @warns in console, if the number of id objects returned is smaller, because the dictionary has not 
 * enough new words. 
 */
async function newWordListforUser(userId, options = {}){
	const { dictionaryId, numWordsToReturn } = options;


	const user = await User.findById(userId);
	if(!user){
		throw new Error(`User with id ${userId} does not exist!`);
	}
	
	let dictId = dictionaryId;
	if(!dictId){
		if(!user.recitingDictionary){
			throw new Error(`User ${user.username} does not has a current reciting dict set.`
			+ `And no dictionaryId is provided to newWordListforUser`);
		}
		dictId = user.recitingDictionary;
	}

	const dictionary = await Dictionary.findById(dictId);
	if(!dictionary){
		throw new Error(`Dictionary with id ${dictId} does not exist!`);
	}
	
	//for each instance of user.words (called word), call word.word_id 
	const userWordIds = new Set(user.words.map(word => word.word_id.toString()));
	const dictionaryWordIds = dictionary.words.map(id => id.toString());

	//for each id in the dictionaryWordIds, add that to newWords if, userWordIds does
	//not have that id. 
	let newWords = dictionaryWordIds.filter(id => !userWordIds.has(id));

	//shuffle the newWords, so we don't start with abandon. 
	shuffle(newWords);

	newWords = newWords.map(id => new mongoose.Types.ObjectId(id));

	//has the user learned enough words? 
	let numWords = numWordsToReturn
	if(!numWords){
		numWords = user.dailyLearnCount - user.numWordsLearnedToday;
	}

	if(newWords.length < numWords){
		numWords = newWords.length;
		console.log(`Warning: user ${user.username} only have ${numWords} words to learn`+ 
		`in dictionary ${dictionary.name}, which is less than target.`);
	}

	if(numWords <= 0){
		numWords = 0
		console.log(`Warning: user ${user.username} is not getting any words to learn`+
		` in this call. Specify positive numWordstoReturn to override.`);
	}
	

	newWords = newWords.slice(0, numWords);

	let newWordObjs = [];
	for(let wordId of newWords){
		const word = await Word.findById(wordId);
		if(word){
			newWordObjs.push({id: word._id, content: {
				originalWord: word.originalWord,
				description: word.description
			}});
		} else {
			throw new Error(`Very rare error in newWordListforUser...`);
		}

	}

	return newWordObjs;
	
}

/**
 * return an array of objects for user to review. Will not give words with fam weight
 * that is greater than the REMEMBER_THRESHOLD. 
 * Format: {id: _id, content:{originalWord:..., description:...}}
 * Optional args: dictionaryId, numWordsToReturn
 * Default to: user.recitingDictionary, and (dailyReviewCount - numWordsReviewedToday)
 * Upper limit is the number of words in user.words, with the dictionaryId. 
 * Usage: reviewWordListforUser(userId, {dictionaryId: foo, numWordsToReturn: bar})
 * where both in {} is optional.
 * 
 * @param {mongoose.Types.ObjectId} userId required.
 * @param {mongoose.Types.ObjectId, Number} options dictionaryId, numWordsToReturn
 * @returns {mongoose.Types.ObjectId[]} - list of reviewWord id objects.
 * @throws {Error} if the user doesn't exist, or no dictionaryId specified AND user has no
 * .recitingDictionary set. (Use setUserRecitingDictionary.), or dictionary doesn't exist.
 * @warns in console, if the numWords to return is <= 0, either because user reviewed enough words,
 * or the numWordsToReturn passed in is negative.
 * @warns in console, if the number of id objects returned is smaller, because user has not 
 * enough words to review in user.words.
 */
async function reviewWordListforUser(userId, options = {}) {
	const { dictionaryId, numWordsToReturn } = options;

	const user = await User.findById(userId);
	if(!user){
		throw new Error(`User with id ${userId} does not exist!`);
	}
	
	let dictId = dictionaryId
	if(!dictId){
		if(!user.recitingDictionary){
			throw new Error(`User ${user.username} does not has a current reciting dict set.`
			+ `And no dictionaryId is provided to reviewWordListforUser`);
		}
		//if no dictonaryId is provided, use user's current reciting Dictionary.
		dictId = user.recitingDictionary;
	}


	const dictionary = await Dictionary.findById(dictId);
	if(!dictionary){
		throw new Error(`Dictionary with id ${dictId} does not exist!`);
	}
	//check: is user reciting this dictionary? (if provided a dictionaryId.)
	//const userWordIds = new Set(user.words.map(word => word.word_id.toString()));
	const userDictIds = new Set(user.words.map(word => word.dictionary_id.toString()));

	if(!userDictIds.has(dictId.toString())){
		console.log(`Warning: user ${user.username} is not actively reciting words` + 
		`In dictionary ${dictionary.name}`);
	}

	let reviewWords = user.words.filter(word => word.dictionary_id.toString() === dictId.toString());
	reviewWords = reviewWords.filter(word => word.familiarity_weight < Constants.REMEMBER_THRESHOLD);
	shuffle(reviewWords);
	reviewWords = reviewWords.map(word => new mongoose.Types.ObjectId(word.word_id));

	//Now, I want to take in an optional argument which specifies the num words to return
	//if the number of words to return is not specified, we return:
	//(dailyReviewCount - numWordsReviewedToday) words.

	let numWords = numWordsToReturn;
	if(!numWords){
		numWords = user.dailyReviewCount - user.numWordsReviewedToday;
		//console.log(`numWords is ${numWords}`);
	}

	
	if(reviewWords.length < numWords){
		numWords = reviewWords.length
		console.log(`Warning: user ${user.username} only have ${numWords} words to review`+ 
		` in dictionary ${dictionary.name}, which is less than target.`);
	}

	if(numWords <= 0){
		numWords = 0;
		console.log(`Warning: user ${user.username} is not getting any words to review`+
		` in this call. Specify positive numWordstoReturn to override.`);
	}
	reviewWords = reviewWords.slice(0, numWords);

	let wordObjs = [];
	for(let wordId of reviewWords){
		const word = await Word.findById(wordId);
		if(word){
			wordObjs.push({id: word._id, content: {
				originalWord: word.originalWord, description: word.description}});
		} else {
			throw new Error(`Very rare error in reviewWordListforUser: word non exist.`);
		}
	}
	return wordObjs;

}

module.exports = {
	newWordListforUser,
	reviewWordListforUser
}

