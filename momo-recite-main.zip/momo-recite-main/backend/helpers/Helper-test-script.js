const helper = require('./Helper-creation-loginout.js');
const userWordHelper = require('./Helper-user-word.js');
const editHelper = require('./Helper-edit-userWordDict.js');
const mongoose = require('mongoose');
const REMOTE_DATABASE_NAME = 'test';
const db_settings = require('./db-settings');
const uri = db_settings.setRemoteDatabase(REMOTE_DATABASE_NAME);
const User = require('../models/User');
const Dictionary = require('../models/Dictionary');
const Word = require('../models/Word.js');


async function deleteAllwords(){
	//DANGER!!!! DONT DO IT.
	try{
		await Word.deleteMany({});
		console.log("All words removed successfully");
	} catch(err){
		console.error("Error deleting word..");
	}
}

async function run() {
	     await mongoose.connect(uri).then(() => console.log('MongoDB connected!'))
	         .catch(err => console.log(err));
	 	//await deleteAllwords();
	     const user = await User.findOne({username: "kevinchen"});
		 if(!user._id){
			throw new Error(`Test script user failed`);
		 }
	     var dictionaryName = "SAT";
	     var pathToDict = 'E:/gitrepo/momo-recite/Vocab/SAT.txt';
	     const dict = await helper.generateDictionaryFromFile(pathToDict, user._id, dictionaryName);
	     console.log(`Dictionary (${dictionaryName}): ${dict}`);
	 }


	 //run().catch(console.error).finally()
	   //  .finally(() => { mongoose.disconnect(); });


async function run2(){
	try{
		await mongoose.connect(uri).then(() => console.log('MongoDB connected!'))
		.catch(err => console.log(err));
		

		//await helper.generateDictionaryFromFile("E:\gitrepo\momo-recite\Vocab\GRE.txt", )
		
		//let user = await helper.createUser("jerryfoo", "barbarbar");
		let user = await User.findOne({username: "test642"});
		console.log(user);
		
		const dictionary = await Dictionary.findOne({name: "GRE"});
		/*
		

		//wait for all promises before returning, and doing some mapping tricks right here. 
		

		
		let word = await Word.findOne({originalWord: "abandon"});
		await editHelper.addWordtoUser(user._id, word._id, dictionary._id);
		word = await Word.findOne({originalWord: "accelerate"});
		//await editHelper.deleteWordfromUser(user._id, word._id);
		word = await Word.findOne({originalWord: "absurd"});
		await editHelper.addWordtoUser(user._id, word._id, dictionary._id);
		word = await Word.findOne({originalWord: "accelerate"});
		//await editHelper.addWordtoUser(user._id, word._id, dictionary._id);

		await editHelper.recordLearnWord(user._id, word._id, "remember", dictionary._id);
		await editHelper.user_setdailyLearnCount(user._id, 15);
		
		await editHelper.setUserRecitingDictionary(user._id, dictionary._id);

		let newWordList = await userWordHelper.newWordListforUser(user._id, {numWordsToReturn: 15});
		const WordList = await Promise.all(newWordList.map(async wordId => {
			const word = await Word.findById(wordId);
			return word.originalWord;
		}))
		console.log(WordList);
		*/
		const reviewWordList = await userWordHelper.reviewWordListforUser(user._id, {numWordsToReturn: 12});
		/*
		const ReviewList = await Promise.all(reviewWordList.map(async wordId => {
			const word = await Word.findById(wordId);
			return word.originalWord;
		}))
		*/
		console.log(reviewWordList);
		user = await User.findOne({username: "test642"});
		console.log(user);
		let allwordList = await editHelper.getAllWordinDict(dictionary._id);
		console.log(allwordList);
		/*
		await editHelper.recordReviewWord(user._id, word._id, "remember");

		let famWeight = await editHelper.getFamWeightforUserWord(user._id, "accelerate");
		console.log(`Accelerate: ${famWeight}`);
		famWeight = await editHelper.getFamWeightforUserWord(user._id, "abandon");
		console.log(`Abandon: ${famWeight}`);
		user = await User.findOne({username: "jerryfoo"});
		console.log(user);
		*/

		
	} catch(err){
		console.log(err);
	} finally{
		mongoose.disconnect();
	}
	
	
}

run2();