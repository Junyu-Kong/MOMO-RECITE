module.exports = {
    secret: "felix-secret-key"
};
  