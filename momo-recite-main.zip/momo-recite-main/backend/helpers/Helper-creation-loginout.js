//Helper.js is exported as a module.
//usage: const helper = require(./backend/models/Helper.js)
//Then call: helper.functionname(parameters...)
//MongoNotConnectedError is often caused by calling async functions directly,
//The functions here all return a PROMISE. use function.then()
//or use await function...
const mongoose = require('mongoose');
const User = require('../models/User');
const Word = require('../models/Word');
const Dictionary = require('../models/Dictionary');
//Assuming, they are in the same directory as test script.
//add ./models/... if run from root directory.
const REMOTE_DATABASE_NAME = 'test';
const db_settings = require('./db-settings');
const fs = require('fs');
const readline = require('readline');
const uri = db_settings.setRemoteDatabase(REMOTE_DATABASE_NAME);

/**
 * Creates a new user.
 *
 * @async
 * @function createUser
 * @param {String} username_data - The username for the new user.
 * @param {String} password_data - The password for the new user.
 * @returns {Promise<User>} The newly created user (document).
 */
async function createUser(username_data, password_data) {

    const newUser = new User({
        username: username_data,
        password: password_data
    });
    try {
        await newUser.save();
    } catch (err) {
        if (err.code === 11000) {
            throw new Error('The user name is already taken!');
        } else {
            throw err;
        }

    }
    return newUser;
}
/**
 * Creates a new user.
 *
 * @async
 * @function createWord
 * @param {String} originalWord_data - The originalWord for the word. 
 * @param {String} description_data - The description data for the word.
 * @returns {Promise<User>} The newly created Word (document).
 * throws error only if, there already exists a word, with same originalWord, 
 * and the description is the same too. 
 */
async function createWord(originalWord_data, description_data) {
    const word = await Word.findOne({ originalWord: originalWord_data });
    if (word) {
        if (word.description === description_data)
            throw new Error(`The word ${originalWord_data} already exists with the same description!`);
    }

    const newWord = new Word({
        originalWord: originalWord_data,
        description: description_data
    });
    await newWord.save();
    return newWord;
}

/**
 * Handle the login of a user, by setting the 'isLoggedin' field to true.
 * If the last login was the previos day, reset the number of words 
 * reviewed ans learned. 
 *
 * @async
 * @function attemptLogin
 * @param {String} username_input - The originalWord for the word. 
 * @param {String} password_input - The description data for the word.
 * @returns {Boolean} true only if user exists and password match.
 * @throws {Error} If the user doesn't exit. 
 */
async function attemptLogin(username_input, password_input) {
    const user = await User.findOne({ username: username_input });
    if (!user) {
        throw new Error('User does not exist! Try registering?');
    }

    if (password_input === user.password) {
		//Checks if last login was the previous day.
		const lastLoginDate = new Date(user.lastLogin);
		const currentDate = new Date();
		const isSameDay = 
			lastLoginDate.getDate() === currentDate.getDate() &&
			lastLoginDate.getMonth() === currentDate.getMonth() &&
			lastLoginDate.getFullYear() === currentDate.getFullYear();
		
		if(!isSameDay){
			user.numWordsLearnedToday = 0;
			user.numWordsReviewedToday = 0;
		}
		
        user.isLoggedin = true;
		user.lastLogin = Date.now();
        await user.save();
        return true;
    }
    else {
        return false;
    }
}
/**
 * Logout a user by setitng their 'isLoggedin' field to false. 
 * @param {String} username_input - The username of the user to log out.
 * @throws {Error} If the user doesn't exist or is not logged in.
 * @returns {Promise<void>} A promise that resolves when user has been logged out. 
 */
async function LogoutUser(username_input) {
    const user = await User.findOne({ username: username_input });
    if (user && user.isLoggedin) {
        user.isLoggedin = false;
        await user.save();
    }
    else {
        throw new Error('User does not exist, or is not logged in.');
    }
}

/**
 * Creates a dictionary with a list of words.
 * 
 * @param {String} dictionary_name - Name of dictionary to be created
 * @param {mongoose.Types.ObjectId} user_creator_id - ID of the user that creates the dictionary.
 * @param {Word[]} wordList - An array of Word documents to be included in the dictionary.
 * @param {Boolean} public_settings - optional, default to true. Mark it false if user marked private.
 * @returns {Promise<Dictionary>} - The newly created dictionary.
 * @throws {Error} If any of the words are not a valid Word instance.
 * @throws {Error} if the user doesn't exist. 
 * @throws {Error} If the dictionary with the same name already exists. 
 */
async function createDictionarywithList_updateUser(dictionary_name, user_creator_id, wordList, public_settings = true) {
    wordList.forEach(word => {
        if (!(word instanceof Word)) {
            throw new Error('Invalid word document passed to create Dictionary!');
        }
    });
    const cur_user = await User.findById(user_creator_id);
    if (!cur_user) {
        throw new Error('The user does not exist!');
    }
    if (cur_user) {
        const ownedDictionaries = await Dictionary.find({ creator: cur_user._id });
        for (let i = 0; i < ownedDictionaries.length; i++) {
            if (dictionary_name === ownedDictionaries[i].name) {
                throw new Error('You already have a dictionary with same name!');
            }
        }
    }

    const newDictionary = new Dictionary({
        name: dictionary_name,
        words: wordList.map(word => word._id),
        //use: wordList.map(word_id => ({ word_id })) if using word id array. 
        creator: user_creator_id,
        public: public_settings
    });
    try {
        await newDictionary.save();
    } catch (err) {   //Actually we have tried to find duplicated dic names before. 
        //I think we should allow different users to create a dictionary with the same name...
        if (err.code === 11000) {
            throw new Error('A dictionary with this name already exists!');
        } else {
            throw err;
        }
    }

    cur_user.dictionaries.push(newDictionary._id);
    await cur_user.save();

    return newDictionary;
}

/**
 * Create an empty dictionary for a user. 
 * Note: use:addWordToDictionary to add existing word to it. 
 * Note: if user has his own file with words, use generateDictionaryFromFile.
 * 
 * @param {mongoose.Types.ObjectId} userId 
 * @param {String} dictionary_name 
 * @param {Boolean} public_settings 
 * @returns {Promise<Dictionary>} the dictionary generated. 
 * @throws {Error} if the user doesn't exist, or the user has a dictionary with same name.
 */
async function createEmptyDictforUser(userId, dictionary_name, public_settings = true){
    const user = await User.findById(userId);
	if(!user){
		throw new Error(`User with id ${userId} does not exist!`);
	}
    
    if (user) {
        const ownedDictionaries = await Dictionary.find({ creator: user._id });
        for (let i = 0; i < ownedDictionaries.length; i++) {
            if (dictionary_name === ownedDictionaries[i].name) {
                throw new Error('You already have a dictionary with same name!');
            }
        }
    }

    const newDictionary = new Dictionary({
        name: dictionary_name,
        words: [],       
        creator: userId,
        public: public_settings
    });

    try {
        await newDictionary.save();
    } catch (err) {   //Actually we have tried to find duplicated dic names before. 
        //I think we should allow different users to create a dictionary with the same name...
        if (err.code === 11000) {
            throw new Error('A dictionary with this name already exists!');
        } else {
            throw err;
        }
    }

    user.dictionaries.push(newDictionary._id);
    await user.save();

    return newDictionary;

}

/**
 * 
 * Generates a dictionary from a text file.
 * Assuming, word and description alternates in lines. 
 * !!!Use this for user defined dictionaries with custom words.
 * !!!Use createEmptyDictforUser for user defined dicts with existing words. 
 * 
 * @async
 * @function generateDictionaryFromFile
 * @param {String} filepath - The PATH to dictionary text file
 * @param {ObjectId} user_creator_id - The id of the creator of this dictionary
 * @param {String} dictionary_name - The name of the dictionary being created
 * @param {Boolean} public_settings - OPTIONAL, default to true, mark as false if user indicates. 
 * @returns {ObjectId} - id of the dictionary created
 * @throws {Error} - // TODO
 */
async function generateDictionaryFromFile(filepath, user_creator_id, dictionary_name, public_settings = true) {
    try {
        //check if the dict name already exist.
        const cur_user = await User.findById(user_creator_id);
        if (!cur_user) {
            throw new Error('The user does not exist!');
        }
        if (cur_user) {
            const ownedDictionaries = await Dictionary.find({ creator: cur_user._id });
            for (let i = 0; i < ownedDictionaries.length; i++) {
                if (dictionary_name === ownedDictionaries[i].name) {
                    throw new Error('You already have a dictionary with same name!');
                }
            }
        }

        const fileStream = fs.createReadStream(filepath);
        const rl = readline.createInterface({
            input: fileStream,
            crlfDelay: Infinity
        });
        
        var wordlist = [];
        let word, description;
        for await (const line of rl){
            if(!word){
                word = line.trim();
            } else {
                description = line.trim();            
                try{
                    console.log(`Now creating word: ${word}`);
                    const newWord = await createWord(word,description);
                    wordlist.push(newWord);
                } catch (err) {
                    try{
                        const existingWord = await Word.findOne({originalWord: word});
                        if(existingWord){
                            console.log(`Previous word already exist, fetching...`);
                            wordlist.push(existingWord);
                        }
                    } catch (fetchErr){
                        console.error(`Failed to fetch existing word: ${fetchErr}`);
                    }
                }
                word = null;
                description = null;
            }
        }
        const dictionary = await createDictionarywithList_updateUser(dictionary_name, user_creator_id, wordlist, public_settings);

        return dictionary._id;
    } catch (err) {
        throw new Error(err);
    }
}
/**
 * Example Usage
 * 
 * async function run() {
 *     await mongoose.connect(uri).then(() => console.log('MongoDB connected!'))
 *         .catch(err => console.log(err));
 * 
 *     const user = await createUser("testuser1", "foofoofoo");
 *     var dictionaryName = "SAT";
 *     var pathToDict = path.join('./Vocab', `${dictionaryName}.txt`);
 *     const dict = await generateDictionaryFromFile(pathToDict, user._i, dictionaryName);
 *     console.log(`Dictionary (${dictionaryName}): ${dict}`);
 * }
 * run().catch(console.error).finally()
 *     .finally(() => { mongoose.disconnect(); });
 * 
 */


module.exports = {
    createUser,
    createWord,
    createDictionarywithList_updateUser,
    attemptLogin,
    LogoutUser,
    generateDictionaryFromFile,
    createEmptyDictforUser
};

/*
async function run1(){
    await mongoose.connect(uri).then(() => console.log('MongoDB connected!'))
    .catch(err => console.log(err));

    const user = await createUser("testuser1", "foofoofoo");
    const word1 = await createWord("abandon", "抛弃，放弃");   
    const word2 = await createWord("test", "测试")
    const dictionary = await createDictionarywithList("testDictionary", 
        user._id, [word1, word2]);

    console.log(user);
    console.log(word1);
    console.log(word2);
    console.log(dictionary);
    
}

async function run2(){
    try{
        await mongoose.connect(uri).then(() => console.log('MongoDB connected!'))
        .catch(err => console.log(err));
        const login_status = await attemptLogin("testuser1", "foofoofoo");
        const test_user = await User.findOne({username: "testuser1"});
        console.log(test_user);
        await LogoutUser("testuser1");
        const test_user_after_logout = await User.findOne({username: "testuser1"});
        console.log(test_user_after_logout);
    } catch(err){
        console.log(err);
    } finally {
        mongoose.disconnect();
    }
}



//run2();
*/



