// connect to DB
require('dotenv').config();
// please set REMOTE_DATABASE_NAME to working DB

function setRemoteDatabase (REMOTE_DATABASE_NAME) {
    const remote_base_uri = "mongodb+srv://";
    const remote_database_uri = "@momo-recite.plz7quf.mongodb.net/";
    const remote_database_options = "?retryWrites=true&w=majority";
    return remote_base_uri + process.env.MONGODB_ACCESS_CODE + remote_database_uri + REMOTE_DATABASE_NAME + remote_database_options;
}

module.exports = { setRemoteDatabase };

