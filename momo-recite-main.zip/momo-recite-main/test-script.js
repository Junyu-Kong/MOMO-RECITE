// .env file and the correct uri required.
// The file is simple, and may be shared in chat in a while. 
//In command line: npm install dotenv
//And, npm install mongodb
//Run the script by: node test-script.js
require('dotenv').config();
const { MongoClient } = require('mongodb');

async function run() {
    const uri = process.env.MONGODB_URI;
    const client = new MongoClient(uri);

    try {
        // Connect to the MongoDB cluster
        await client.connect();

        // Specify the database and collection
        const db = client.db("test"); //Yes, it will have the name test until 
                //I have time to figure out how to change it. 
        const collection = db.collection("TestDictionary"); 

        // Insert a document
        const newWord = { 
            word: "你好啊！", 
            meaning: "greeting in Chinese", 
            language: "Chinese",
            familiar_weight: 0.5,
            date_added: new Date()
        };
        const result = await collection.insertOne(newWord);
        console.log(`New listing created with the following id: ${result.insertedId}`);

        // Find a document (Hmm, here, a word is a "document", it's NOT a full file!)
        const wordToFind = { word: "hello"};
        const foundWord = await collection.findOne(wordToFind);
        console.log(`Found word: ${foundWord.word}, meaning: ${foundWord.meaning}, 
        language: ${foundWord.language}`);

        //Update a document: 
        const wordToUpdate = {familiar_weight: {$gt: 0.5}}; //gt: greater than.
        const updateResult = await collection.updateOne(wordToUpdate, {$set: {familiar_weight: 0.0}});
        console.log(`Updated ${updateResult.modifiedCount} word(s)`);
        
        //There are also find and updateMany, and many more! Type in in visual studio code and see 
        //what is available. 

    } catch (e) {
        //From gpt: don't forget to handle the outcome!!!
        console.error(e);
    } finally {
        await client.close();
    }
}

run().catch(console.dir);
