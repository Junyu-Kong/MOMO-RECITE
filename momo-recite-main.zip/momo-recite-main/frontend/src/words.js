import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const Words = () => {
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/auth/verifyLogin", {
      withCredentials: true,
    })
    .catch((err) => {
      if (err.response.status === 403) {
        navigate("/main");
      }
      else {
        console.log(err);
      }
    })
  },[]);

  const [option, setOption] = useState("remember");
  const [highFamiliarityWords, setHighFamiliarityWords] = useState([]);
  const [mediumFamiliarityWords, setMediumFamiliarityWords] = useState([]);
  const [lowFamiliarityWords, setLowFamiliarityWords] = useState([]);
  var words = [];

  useEffect(() => {
    let mounted = true;

      const fetchData = async () => {
          try {
              const response = await axios.post(
                  "http://localhost:5000/api/user/wordsBasedOnFam",
                  null,
                  { withCredentials: true }
              );
              if (mounted) {
                  setHighFamiliarityWords(response.data.highFamiliarityWords);
                  setMediumFamiliarityWords(response.data.mediumFamiliarityWords);
                  setLowFamiliarityWords(response.data.lowFamiliarityWords);
              }
          } catch (err) {
              console.log(err);
              // Handle error
          }
      };

      fetchData();

      return () => {
        mounted = false;
      };
  }, []);


  const WordsComponent = () => {
      if (option === "familiar") {
          words = highFamiliarityWords;
      } else if (option === "blurry") {
          words = mediumFamiliarityWords;
      } else if (option === "forget") {
          words = lowFamiliarityWords;
      }
      // FIX here
      return words.map((word, index) => {
          return <li key={index}>{word.originalWord}: {word.description}</li>;
      });
  };

  return (
      <div className="container">
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>

          <main>
              <div id="option">
                  <button className="green" onClick={() => setOption("familiar")}>familiar</button>
                  <button className="yellow" onClick={() => setOption("blurry")}>blurry</button>
                  <button className="red" onClick={() => setOption("forget")}>forget</button>
              </div>
              <div >
                  <ul className="words">
                      <WordsComponent />
                  </ul>
              </div>
          </main>

          <nav>
            <ul>
              <li>
                <Link to="/review">Review</Link>
              </li>
              <li>
                <Link to="/dictionary">Select Dictionary</Link>
              </li>
              <li>
                <Link to="/words">My Words</Link>
              </li>
              <li>
                <Link to="/user">User</Link>
              </li>
              <li>
                <Link to="/logout">Logout</Link>
              </li>
            </ul>
          </nav>

          <style jsx="true">{`
      body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background-color: #f2f2f2;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        height: 100vh;
      }
      .head {
        color: #fff;
        text-decoration: none;
      }
      .words {
        text-align: left;
        width: 450px;
        margin-left: 50px;
      }
      .words li {
        margin-left: 10px;
        font-size: 16px;
      }
      header {
        background-color: #333;
        color: #fff;
        padding: 20px;
        text-align: center;
      }
      .logo {
        width: 75px;
        height: auto;
        position: absolute;
        top: 4px;
        left: 8px;
      }
      h1 {
        margin: 0;
      }
      h2 {
        margin: 0;
      }

      main {
        flex: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        padding: 20px;
        text-align: center;
        margin-bottom: 100px;
      }

      #option {
        margin-top: 20px;
        display: flex;
        justify-content: center;
      }

      .green {
        margin: 0 10px;
        padding: 10px 20px;
        background-color: #25a55f;
        color: #fff;
        border: none;
        cursor: pointer;
      }

      .yellow {
        margin: 0 10px;
        padding: 10px 20px;
        background-color: #ffd700;
        color: #fff;
        border: none;
        cursor: pointer;
      }

      .red {
        margin: 0 10px;
        padding: 10px 20px;
        background-color: #ff0000;
        color: #fff;
        border: none;
        cursor: pointer;
      }

      label {
        display: block;
        margin-bottom: 5px;
        text-align: left;
        font-size: 20px;
      }

      select {
        width: 200px;
        height: 30px;
      }

      nav {
        background-color: #333;
        color: #fff;
        text-align: center;
        padding: 20px;
        position: fixed;
        bottom: 0;
        left: 0;
        right: 0;
        width: auto;
      }

      nav ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
      }

      nav ul li {
        display: inline;
        margin-right: 10px;
      }

      nav ul li a {
        color: #fff;
        text-decoration: none;
        padding: 10px;
        font-size: 18px;
      }

      nav ul li a:hover {
        color: grey;
      }
    `}</style>
      </div>
  );
};

export default Words;
