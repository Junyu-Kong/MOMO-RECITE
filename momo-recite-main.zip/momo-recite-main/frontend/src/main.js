import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "react-router-dom";

const Main = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(2);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/auth/verifyLogin", {
        withCredentials: true,
      })
      .then(() => {
        setIsLoggedIn(1);
      })
      .catch((err) => {
        if (err.response.status === 403) setIsLoggedIn(0);
        else console.log(err.request.response);
        return;
      });
  }, []);

  const NavBar = () => {
    switch (isLoggedIn) {
      case 2:
        return <nav></nav>;
      case 0:
        return (
          <nav>
            <ul>
              <li>
                <Link to="/register">Register</Link>
              </li>
              <li>
                <Link to="/login">Login</Link>
              </li>
            </ul>
          </nav>
        );
      case 1:
        return (
          <nav>
            <ul>
              <li>
                <Link to="/review">Review</Link>
              </li>
              <li>
                <Link to="/dictionary">Select Dictionary</Link>
              </li>
              <li>
                <Link to="/words">My Words</Link>
              </li>
              <li>
                <Link to="/user">User</Link>
              </li>
              <li>
                <Link to="/logout">Logout</Link>
              </li>
            </ul>
          </nav>
        );
      default:
        return;
    }
  };

  return (
    <div className="container">
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>

      <main>
        <h2>Welcome to Momo Recite!</h2>
        <p>
          Start your language learning journey by reviewing words, selecting
          dictionaries, checking statistics, and managing your user profile.
        </p>
      </main>

      <NavBar />

      <style jsx="true">{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f2f2f2;
        }

        header {
          background-color: #333;
          color: #fff;
          padding: 20px;
          text-align: center;
        }
        .head {
          color: #fff;
          text-decoration: none;
        }
        h1 {
          margin: 0;
        }
        h2 {
          color: #333;
        }
        .logo {
          width: 75px;
          height: auto;
          position: absolute;
          top: 4px;
          left: 8px;
        }
        main {
          padding: 20px;
          text-align: center;
        }

        nav {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 20px;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          width: auto;
        }

        nav ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
        }

        nav ul li {
          display: inline;
          margin-right: 10px;
        }

        nav ul li a {
          color: #fff;
          text-decoration: none;
          padding: 10px;
          font-size: 18px;
        }

        nav ul li a:hover {
          color: grey;
        }
      `}</style>
    </div>
  );
};

export default Main;
