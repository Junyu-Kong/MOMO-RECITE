import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const User = () => {
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/auth/verifyLogin", {
        withCredentials: true,
      })
      .then((res) => {
        setUsername(res.data.username);
      })
      .catch((err) => {
        if (err.response.status === 403) {
          navigate("/main");
        } else {
          console.log(err.response.data.message);
        }
      });

    refreshContents();
  }, []);

  const [newWordcount, setNewWordcount] = useState("");
  const [reviewWordcount, setReviewWordcount] = useState("");
  const [currentNewWordCount, setCurrentNewWordCount] = useState(undefined);
  const [currentReviewWordCount, setCurrentReviewWordCount] = useState(undefined);
  const [numLearned, setNumLearned] = useState(undefined);
  const [numReviewed, setNumReviewed] = useState(undefined);
  const [username, setUsername] = useState(undefined);

  const getNewWordCount = async () => {
    axios
    .get("http://localhost:5000/api/recite/getDailyLearnCount", {
      withCredentials: true,
    })
    .then((res) => {
      setCurrentNewWordCount(res.data.value);
    })
    .catch((err) => {
      console.log(err.response.data.message);
    });
  }

  const getReviewWordCount = async () => {
    axios
    .get("http://localhost:5000/api/recite/getDailyReviewCount", {
      withCredentials: true,
    })
    .then((res) => {
      setCurrentReviewWordCount(res.data.value);
    })
    .catch((err) => {
      console.log(err.response.data.message);
    });
  }

  const getNumberLearnedToday = async () => {
    axios
    .get("http://localhost:5000/api/recite/getNumLearn", {
      withCredentials: true,
    })
    .then((res) => {
      setNumLearned(res.data.value);
    })
    .catch((err) => {
      console.log(err.response.data.message);
    });
  }

  const getNumberReviewedToday = async () => {
    axios
    .get("http://localhost:5000/api/recite/getNumReview", {
      withCredentials: true,
    })
    .then((res) => {
      setNumReviewed(res.data.value);
    })
    .catch((err) => {
      console.log(err.response.data.message);
    });
  }
  
  const refreshContents = async () => {
    getNewWordCount();
    getReviewWordCount();
    getNumberLearnedToday();
    getNumberReviewedToday();
  }

  const handleNewWordCount = async (e) => {
    e.preventDefault();

    if (newWordcount <= 0) {
      alert("Number should be greater than 0.");
      return;
    }

    axios
      .post(
        "http://localhost:5000/api/user/dailyLearnCount",
        {
          dailyLearnCount: newWordcount,
        },
        { withCredentials: true }
      )
      .then((res) => {
        refreshContents();
        // alert(res.data.message);
      })
      .catch((err) => {
        alert(err.response.data.message);
        console.log(err.response.data.message);
      });
  };

  const handleReviewWordCount = async (e) => {
    e.preventDefault();

    if (reviewWordcount <= 0) {
      alert("Number should be greater than 0.");
      return;
    }

    axios
      .post(
        "http://localhost:5000/api/user/dailyReviewCount",
        {
          dailyReviewCount: reviewWordcount,
        },
        { withCredentials: true }
      )
      .then((res) => {
        refreshContents();
        // alert(res.data.message);
      })
      .catch((err) => {
        console.log(err.response.data.message);
        alert(err.response.data.message);
      });
  };

  return (
    <div className="container">
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>

      <main>
        <div className="username">Username: {username}</div>
        <div className="settings">
          <div className="checkbox-group">
            <form onSubmit={handleNewWordCount}>
              <label className="label" htmlFor="newWordcount">
                {"Set number of words to learn every day: "}
                <input
                  type="number"
                  id="newWordcount"
                  name="newWordcount"
                  value={newWordcount}
                  onChange={(e) => setNewWordcount(e.target.value)}
                  required
                />
                <input type="submit" value="Save" />
              </label>
            </form>
            <form onSubmit={handleReviewWordCount}>
              <label className="label" htmlFor="reviewWordcount">
                {"Set number of words to review every day: "}
                <input
                  type="number"
                  id="reviewWordcount"
                  name="reviewWordcount"
                  value={reviewWordcount}
                  onChange={(e) => setReviewWordcount(e.target.value)}
                  required
                />
                <input type="submit" value="Save" />
              </label>
            </form>
          </div>
        </div>
        <div className="report">
              <p>
                <label htmlFor="file">New Word Progress: {numLearned} / {currentNewWordCount}</label>
                <progress max={currentNewWordCount} value={numLearned}></progress>
              </p>
              <p>
                <label htmlFor="file">Review Word Progress: {numReviewed} / {currentReviewWordCount}</label>
                <progress max={currentReviewWordCount} value={numReviewed}></progress>
              </p>
            </div>
      </main>

      <nav>
        <ul>
          <li>
            <Link to="/review">Review</Link>
          </li>
          <li>
            <Link to="/dictionary">Select Dictionary</Link>
          </li>
          <li>
            <Link to="/words">My Words</Link>
          </li>
          <li>
            <Link to="/user">User</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>

      <style jsx="true">{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f2f2f2;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          height: 100vh;
        }
        .head {
          color: #fff;
          text-decoration: none;
        }
        label {
          display: block;
          margin-bottom: 5px;
          text-align: left;
        }
        p {
          display: block;
          margin-bottom: 5px;
          text-align: left;
          font-size: 16px;
        }
        .username {
          font-size: 24px;
          margin-bottom: 10px;
          text-align: left;
        }
        .content {
          text-align: left;
          display: flex;
        }
        .checkbox-group {
          margin-top: 20px;
          text-align: left;
          margin-left: 20px;
        }
        header {
          background-color: #333;
          color: #fff;
          padding: 20px;
          text-align: center;
        }

        h1 {
          margin: 0;
        }
        h2 {
          color: #333;
        }
        .logo {
          width: 75px;
          height: auto;
          position: absolute;
          top: 4px;
          left: 8px;
        }

        main {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;
          padding: 20px;
          text-align: center;
        }
        form {
          display: flex;
          align-items: center;
          justify-content: center;
        }

        input[type="submit"] {
          margin-left: 10px;
        }
        nav {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 20px;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          width: auto;
        }

        nav ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
        }

        nav ul li {
          display: inline;
          margin-right: 10px;
        }

        nav ul li a {
          color: #fff;
          text-decoration: none;
          padding: 10px;
          font-size: 18px;
        }

        nav ul li a:hover {
          color: grey;
        }
      `}</style>
    </div>
  );
};

export default User;

