import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const Review = () => {
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/auth/verifyLogin", {
      withCredentials: true,
    })
      .catch((err) => {
        if (err.response.status === 403) {
          navigate("/main");
        }
        else {
          console.log(err);
        }
      })
  }, []);


  const [show, setShow] = useState(false);
  const [word, setWord] = useState("Click here to begin");
  const [translation, setTranslation] = useState("翻译");
  const [attrs, setAttrs] = useState({ id: null, review: null });
  const [wordlist, setWordlist] = useState([]);
  const [exists, setExists] = useState(0);
  const [clicked, setClicked] = useState(false);

  useEffect(() => {
    axios.get('http://localhost:5000/api/user/currentDictionary',
      { withCredentials: true })
      .then((res) => {
        axios.post('http://localhost:5000/api/recite/getWordlist', null,
        { withCredentials: true })
          .then((res) => {
            if (res.status === 204) {
              setExists(3);
            }
            else {
              setExists(1);
            }
          })
      })
      .catch((err) => {
        setExists(2);
        console.log(err.response.data.message);
      });
  }, []);

  const ReviewComponent = () => {
    switch (exists) {
      case 0:
        return (
          <main>Loading...</main>
        )
      case 1:
        return (
          <main>
            {show ? (
              <div>
                <div id="word" onClick={handleWordClick}>{translation}</div>
                <div id="option">
                  <button className="green" onClick={() => handleOption("remember")}>familiar</button>
                  <button className="yellow" onClick={() => handleOption("somewhatRemember")}>blurry</button>
                  <button className="red" onClick={() => handleOption("forgot")}>don't know</button>
                </div>
              </div>
            ) : (
              <div id="word" onClick={handleWordClick}>{word}</div>
            )}
          </main>
        )
      case 2:
        return (
          <main>
            <h2>You have not set your dictionary yet!</h2>
            <p>
              Go to your user profile to set which dictionary you want to learn.
            </p>
          </main>
        )
      case 3:
        return (
          <main>
            <h2>You are done with learning today!</h2>
            <p>
              Go to your user profile to change daily learning limits if you want to learn more.
            </p>
          </main>
        )
      default:
        return;
    }
  }


  function changeWord(wordlist) {
    let word = wordlist.pop();
    setWord(word.content.originalWord);
    setTranslation(word.content.description);
    setAttrs({ id: word.id, review: word.review });
    return wordlist;
  }

  const handleWordClick = async () => {
    try {
      if (clicked)
        return;
      setClicked(true);

      if (wordlist.length === 0 && word === "Click here to begin") {
        let res = await axios.post('http://localhost:5000/api/recite/getWordlist', null,
        { withCredentials: true });
        if (res.status === 204) {
          setExists(3);
          return;
        }
        var tempWordlist = res.data.value;
        tempWordlist = changeWord(tempWordlist);
        setWordlist(tempWordlist);
      }
      else {
        setShow(!show);
      }
      setClicked(false);
    } catch (err) {
      console.log(err);
    }
  }

  const handleOption = async (option) => {
    try {
      if (clicked)
        return;
      setClicked(true);

      if (attrs.review)
        var goToString = 'Review';
      else
        var goToString = 'Learn';

      await axios.post('http://localhost:5000/api/recite/update' + goToString, {
        curChoice: option,
        curWord: attrs.id
      }, { withCredentials: true })


      let res = await axios.post('http://localhost:5000/api/recite/getWordlist',
      { numWordsLeft: wordlist.length,
        numEachClass: (() => {
        let result = {}
        wordlist.forEach(function(word) {
          result[word.review] ? result[word.review]++ :  result[word.review] = 1;
        });
        return result;
        })()
      },
      { withCredentials: true });
      
      if (wordlist.length === 0) {
        if (res.status === 204) {
          setExists(3);
          return;
        }
        var tempWordlist = res.data.value;
      }
      else 
        var tempWordlist = wordlist;

      tempWordlist = changeWord(tempWordlist);
      setShow(false);
      setClicked(false);
      setWordlist(tempWordlist);

      if (res.status === 205) {
        window.location.reload();
        return;
      }
    } catch (err) {
      console.log(err.request.response);
      alert(err.request.response);
    };
  };

  return (
    <div className="container">
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>

      <ReviewComponent />

      <nav>
        <ul>
          <li>
            <Link to="/review">Review</Link>
          </li>
          <li>
            <Link to="/dictionary">Select Dictionary</Link>
          </li>
          <li>
            <Link to="/words">My Words</Link>
          </li>
          <li>
            <Link to="/user">User</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>

      <style jsx="true">{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f2f2f2;
        }

        header {
          background-color: #333;
          color: #fff;
          padding: 20px;
          text-align: center;
        }
        .head {
          color: #fff;
          text-decoration: none;
        }
        h1 {
          margin: 0;
        }
        h2 {
          color: #333;
        }
        main {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 20px;
          text-align: center;
        }

        #word {
          font-size: 36px;
          margin-bottom: 20px;
          cursor: pointer;
        }

        #option {
          margin-top: 20px;
          display: flex;
          justify-content: center;
        }
        .logo {
          width: 75px;
          height: auto;
          position: absolute;
          top: 4px;
          left: 8px;
        }

        .green {
          margin: 0 10px;
          padding: 10px 20px;
          background-color: #25a55f;
          color: #fff;
          border: none;
          cursor: pointer;
        }
  
        .yellow {
          margin: 0 10px;
          padding: 10px 20px;
          background-color: #ffd700;
          color: #fff;
          border: none;
          cursor: pointer;
        }
  
        .red {
          margin: 0 10px;
          padding: 10px 20px;
          background-color: #ff0000;
          color: #fff;
          border: none;
          cursor: pointer;
        }

        nav {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 20px;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          width: auto;
        }

        nav ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
        }

        nav ul li {
          display: inline;
          margin-right: 10px;
        }

        nav ul li a {
          color: #fff;
          text-decoration: none;
          padding: 10px;
          font-size: 18px;
        }

        nav ul li a:hover {
          color: grey;
        }
      `}</style>
    </div>
  );
};

export default Review;
