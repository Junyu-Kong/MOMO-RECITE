import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const Dictionary = () => {
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/auth/verifyLogin", {
      withCredentials: true,
    })
      .catch((err) => {
        if (err.response.status === 403) {
          navigate("/main");
        }
        else {
          console.log(err.response.data.message);
        }
      })
  }, []);

  const [actualDict, setActualDict] = useState("");
  const [displayDict, setDisplayDict] = useState({ id: "" });
  const [dictionaries, setDictionaries] = useState([]);
  const [displayUpload, setDisplayUpload] = useState(false);
  const [selectCreate, setSelectCreate] = useState(false);

  useEffect(() => {
    fetchCurrentDictionary();
    fetchDictionaries();
  }, []);

  const fetchCurrentDictionary = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/user/currentDictionary",
        { withCredentials: true }
      );
      const curDict = response.data.cur_dict;
      if (curDict) {
        setActualDict(curDict);
        setDisplayDict(curDict);
      }
    } catch (err) {
      console.log(err.response.data.message);
    }
  };

  const fetchDictionaries = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/user/allAccessibleDictionary",
        { withCredentials: true }
      );
      setDictionaries(response.data.dictionaries);
    } catch (err) {
      console.log(err.response.data.message);
    }
  };

  const LoadingComponent = () => {
    return <ul>Loading...</ul>;
  }

  const WordsComponent = () => {
    const [words, setWords] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
      let mounted = true;

      const fetchWords = async () => {
        try {
          if (dictionaries.length === 0)
            return;

          if (displayDict.id === "") {
              setIsLoading(false);
            return;
          }

          const response = await axios.post(
            "http://localhost:5000/api/user/getWordsFromDictionary",
            { dict_id: displayDict.id },
            { withCredentials: true }
          );

          if (mounted) {
            const fetchedWords = response.data;
            setWords(fetchedWords);
            setIsLoading(false);
          }
        } catch (err) {
          console.log(err.response.data.message);
        }
      };

      fetchWords();

      return () => {
        mounted = false;
      };
    }, [displayDict.id]);

    if (isLoading) {
      return <LoadingComponent />;
    }

    return (
      <div className="words">
        {words.map((word, index) => (
          <div className="row" key={index}>
            <div className="left">{word.originalWord}</div>
            <div className="right">{word.description}</div>
          </div>
        ))}
        <style jsx="true">{`
        .words {
          width: 100%;
          margin-top: 30px;
        }
        .row {
          display: flex;
          margin-top: 10px;
          margin-left: 40%;
        }
        
        .left {
          flex: 15%;
          text-align: left;
        }

        .right {
          flex: 80%;
          text-align: left;
        }
        `}</style>
      </div>
    );
  };

  const CreateComponent = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [isPublic, setIsPublic] = useState(true);
    const [dictname, setDictname] = useState("");

    const handleFileChange = (e) => {
      setSelectedFile(e.target.files[0]);
    };

    const handleUpload = async () => {
      if (!selectedFile) {
        alert("Please first select a file!");
        return;
      }
      if (!dictname) {
        alert("Please enter dictionary name!");
        return;
      }

      const formData = new FormData();
      formData.append("file", selectedFile);

      try {
        const res = await axios.post("http://localhost:5000/upload",
          formData, 
          { withCredentials: true,});

        if (res.data.value) {
          alert("File upload is successful");
          await axios.post("http://localhost:5000/api/user/createDictionary", {
            filename: res.data.value,
            dict_name: dictname,
            public: isPublic,
          }, { withCredentials: true })
          .then((res) => {
            alert(res.data.message);
            window.location.reload();
            return;
          })
          .catch((err) => {
            alert(err.response.data.message);
          })

        } else {
          alert("Failed to upload the file due to errors");
        }

      } catch (error) {
        console.log(error);
        alert("Error occurred while uploading the file");
      }
    };

    return (
      <div className="file">
        <p>Create a new dictionary:</p>
        <input type="file" onChange={handleFileChange} />
        <button onClick={handleUpload}>Upload</button>
        <div className="settings">
          Name:
          <input
            type="text"
            required
            value={dictname}
            onChange={(e) => setDictname(e.target.value)}
          />
          <select
            className="public"
            name="selectedPublicValue"
            defaultValue={true}
            onChange={(e) => setIsPublic(e.target.value)}
          >
            <option value={true}>Public</option>
            <option value={false}>Private</option>
          </select>
        </div>
        <style jsx="true">{`
      .file {
        align-items: center;
        padding: 10px;
        text-align: center;
        margin-bottom: 80px;
      }
      .file p {
        display: block;
        margin-bottom: 5px;
        text-align: center;
        font-size: 20px;
      }
      .settings {
        margin-top: 10px;
      }
      .settings input[type="text"] {
        width: 200px;
        height: 23px;
        margin-left: 10px;
      }
      .public {
        width: 80px;
        height: 25px;
        margin-left: 10px;
      }
      input[type="submit"] {
        margin-top: 10px;
        padding: 10px 20px;
        background-color: #333;
        color: #fff;
        border: none;
        cursor: pointer;
      }
      `}</style>
      </div>
    );
  };

  const handleCreate = () => {
    setDisplayUpload(!displayUpload);
    setSelectCreate(!selectCreate);
  }

  const handleSelectDictionary = async (e) => {
    e.preventDefault();

    if (actualDict === displayDict) {
      alert("You're already learning this dictionary!");
      return;
    }
    if (Object.keys(displayDict).length === 1) {
      alert("Please select a dictionary!");
      return;
    }

    axios
      .post(
        "http://localhost:5000/api/user/recitingDictionary",
        {
          recitingDictionary: displayDict.id,
        },
        { withCredentials: true }
      )
      .then((res) => {
        alert(res.data.message);
        fetchCurrentDictionary();
      })
      .catch((err) => {
        alert(err.response.data.message);
        console.log(err.response.data.message);
      });
  };

  return (
    <div className="container">
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>

      <main>
        {actualDict === null ? (
          <h2>You haven't selected your dictionary</h2>
        ) : (
          <h2>Your Current dictionary is: {actualDict.name}</h2>
        )}

        <form onSubmit={handleSelectDictionary}>
          <label htmlFor="dictionary">Choose a new dictionary:</label>
          <select
            id="dictionary"
            name="dictionary"
            value={displayDict.id}
            onChange={(e) => {
              e.target.value != "" ?
              setDisplayDict({
                id: dictionaries.find(x => x.dict_id === e.target.value).dict_id,
                name: dictionaries.find(x => x.dict_id === e.target.value).dict_name
              })
              : setDisplayDict({ id: "" })
            }}
          >
            <option value="">--</option>
            {dictionaries.length > 0 ? (
              dictionaries.map((dict) => (
                <option key={dict.dict_id} value={dict.dict_id} name={dict.dict_name}>
                  {dict.dict_name}
                </option>
              ))
            ) : (
              <option value="">No dictionaries available</option>
            )}
          </select>

          <input type="submit" value="Select" />
        </form>
        <input onClick={handleCreate} type="submit"
          value={selectCreate ? "Go Back to Browsing" : "Create New Dictionary"} />

        {displayUpload ? <CreateComponent /> : <WordsComponent />}

      </main>

      <nav>
        <ul>
          <li>
            <Link to="/review">Review</Link>
          </li>
          <li>
            <Link to="/dictionary">Select Dictionary</Link>
          </li>
          <li>
            <Link to="/words">My Words</Link>
          </li>
          <li>
            <Link to="/user">User</Link>
          </li>
          <li>
            <Link to="/logout">Logout</Link>
          </li>
        </ul>
      </nav>

      <style jsx="true">{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f2f2f2;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          height: 100vh;
        }
        .head {
          color: #fff;
          text-decoration: none;
        }
        .logo {
          width: 75px;
          height: auto;
          position: absolute;
          top: 4px;
          left: 8px;
        }

        .username {
          font-size: 24px;
          margin-bottom: 10px;
          text-align: left;
        }
        .content {
          text-align: left;
        }
        .password {
          display: flex;
          align-items: center;
          margin-bottom: 10px;
        }
        .password-span {
          margin-right: 5px;
        }
        .password-toggle {
          cursor: pointer;
          color: blue;
          text-decoration: underline;
          margin-left: 5px;
        }
        .checkbox-group {
          margin-top: 20px;
          text-align: left;
        }
        header {
          background-color: #333;
          color: #fff;
          padding: 20px;
          text-align: center;
        }

        h1 {
          margin: 0;
        }
        h2 {
          margin: 0;
        }

        main {
          flex: 1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;
          padding: 20px;
          text-align: center;
          margin-bottom: 100px;
        }
        form {
          margin-top: 20px;
        }
        label {
          display: block;
          margin-bottom: 5px;
          text-align: center;
          font-size: 20px;
        }

        select {
          width: 200px;
          height: 30px;
          margin-right: 10px;
        }
        input[type="submit"] {
          margin-top: 10px;
          padding: 10px 20px;
          background-color: #333;
          color: #fff;
          border: none;
          cursor: pointer;
        }
        nav {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 20px;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          width: auto;
        }

        nav ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
        }

        nav ul li {
          display: inline;
          margin-right: 10px;
        }

        nav ul li a {
          color: #fff;
          text-decoration: none;
          padding: 10px;
          font-size: 18px;
        }

        nav ul li a:hover {
          color: grey;
        }
      `}</style>
    </div>
  );
};

export default Dictionary;
