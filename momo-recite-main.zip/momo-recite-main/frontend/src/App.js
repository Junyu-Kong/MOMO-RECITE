import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate
} from "react-router-dom";
import Register from "./register";
import Login from "./login";
import Logout from "./logout";
import Main from "./main";
import User from "./user";
import Dictionary from "./dictionary";
import Review from "./review";
import Words from "./words";

const App = () => {
  return (
      <Router>
        <div>
          <Routes>
            <Route path="/register" element={<Register />} />
            <Route path="/login" element={<Login />} />
            <Route path="/logout" element={<Logout />} />
            <Route path="/main" element={<Main />} />
            <Route path="/user" element={<User />} />
            <Route path="/dictionary" element={<Dictionary />} />
            <Route path="/review" element={<Review />} />
            <Route path="/words" element={<Words />} />
            <Route path='/' element={<Main />}  />
            <Route path='*' element={<Main />}  />
          </Routes>
        </div>
      </Router>
  );
};

export default App;
