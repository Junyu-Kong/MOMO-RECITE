import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();

  useEffect(() => {
    axios.get("http://localhost:5000/api/auth/verifyLogin", {
      withCredentials: true,
    })
    .then(() => {
      navigate("/main");
    })
    .catch((err) => {
      if (err.response.status != 403)
        console.log(err);
    })
  },[]);
  
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleRegister = async (e) => {
    e.preventDefault();

    axios
      .post(
        "http://localhost:5000/api/auth/signup",
        {
          username,
          password,
        },
        { withCredentials: true }
      )
      .then((res) => {
        alert(res.data.message);
        navigate("/login");
      })
      .catch((err) => {
          alert(err.response.data.message);
          console.log(err.response.data.message);
      });
  };

  return (
    <div>
      <header>
        <img src={require("./img/MOMO_RECITE.jpg")} alt="Logo" className="logo" />
        <h1>
          <Link to="/main" className="head">
            Momo Recite
          </Link>
        </h1>
      </header>
      <div className="container">
        <h1 className="page">MOMO RECITE - Sign up</h1>
        <form onSubmit={handleRegister}>
          <div className="form-group">
            <label htmlFor="username">Username:</label>
            <input
              type="text"
              id="username"
              name="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <input type="submit" value="Sign up" />
          </div>
          <div className="form-group login-link">
            Already have an account?{" "}
            <Link to="/login">Click here to login</Link>
          </div>
        </form>
      </div>
      <nav>
        <ul>
          <li>
            <Link to="/register">Register</Link>
          </li>
          <li>
            <Link to="/login">Login</Link>
          </li>
        </ul>
      </nav>
      <style jsx="true">{`
        body {
          font-family: Arial, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f2f2f2;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          height: 100vh;
        }
        .head {
          color: #fff;
          text-decoration: none;
        }
        header {
          background-color: #333;
          color: #fff;
          padding: 20px;
          text-align: center;
        }
        h1 {
          margin: 0;
        }
        .container {
          max-width: 400px;
          margin: 0 auto;
          padding: 20px;
          background-color: #fff;
          border-radius: 5px;
          box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
          text-align: center;
        }
        .page {
          text-align: center;
          margin-bottom: 20px;
        }
        .form-group {
          margin-bottom: 15px;
        }

        label {
          display: block;
          margin-bottom: 5px;
          font-weight: bold;
        }

        input[type="text"],
        input[type="password"] {
          width: 90%;
          padding: 8px;
          border: 1px solid #ccc;
          border-radius: 3px;
        }

        input[type="submit"] {
          width: 90%;
          padding: 8px;
          background-color: #25a55f;
          border: none;
          color: #fff;
          cursor: pointer;
          border-radius: 3px;
        }
        .logo {
          width: 75px;
          height: auto;
          position: absolute;
          top: 4px;
          left: 8px;
        }

        input[type="submit"]:hover {
          background-color: #45a049;
        }

        .login-link {
          text-align: center;
          margin-top: 10px;
        }
        nav {
          background-color: #333;
          color: #fff;
          text-align: center;
          padding: 20px;
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          width: auto;
        }

        nav ul {
          list-style-type: none;
          margin: 0;
          padding: 0;
        }

        nav ul li {
          display: inline;
          margin-right: 10px;
        }

        nav ul li a {
          color: #fff;
          text-decoration: none;
          padding: 10px;
          font-size: 18px;
        }

        nav ul li a:hover {
          color: grey;
        }
      `}</style>
    </div>
  );
};

export default Register;
