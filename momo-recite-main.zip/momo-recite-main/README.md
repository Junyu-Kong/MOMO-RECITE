# Momo-Recite Overview 

Momo-Recite is a flashcard word memorization web app based on React and NodeJS. It allows users with any language background to learn vocabulary for tests, such as the GRE or SAT for Chinese speakers. 
Link to github repo: https://github.com/Vulpxs-M/momo-recite

# Features

1. You can set your own daily goal 

    Users can set the amount of new words they want learn, and the amount of old words to review in a day.

2. App will help you to memorize more efficiently!

    When memorizing, the unfamiliar word will first appear, and the user has unlimited time to recall its translation or definition from memory. Then, the user can click on the word to see its correct translation or definition to verify their own memorization. Then the user will be given three choice to select: "familiar", "blurry", or "don't know". Our app will store that information and help you review the words based on your familarity of the words and update that after reviewing. We hope this will ease students' burden on word memorization during language learning.

3. Encrypted user login/logout/register

    Your info on our database will be encrypted and safely stored!
    
4. Progress Tracking

    User will be able to see a progress bar on their daily review and learn progress. Daily progress will be cleared automatically in the following day.

5. Check all learned words based on familarity

    User can choose "familiar", "blurry", "forgot" on My Words page, and our app will show all the words that falls into the selected category. 

6. Select Dictionary Preset

    Users can select one of our dictionary presets to learn from. Our app will display all the words in a dictionary for users to pick the one they prefer. Currently only some are supported, but the selections are easily expandable in the future.
    
7. Create Public and Private Dictionaries

    Users can create their own dictionaries and set whether they want to share them with others upon creation. All users can browse and learn with public dictionaries.


# Running the App   

Now let's go through the steps of running the app locally through the development version.

1. Open the command-line interface on your local machine (e.g., Terminal on Mac, Command Prompt or PowerShell on Windows) and clone the GitHub repository using  
```sh 
git clone https://github.com/Vulpxs-M/momo-recite/.git 
```  

2. Open two windows of the command line interface and change into the directory that contains the app, then change into the backend and frontend folders. Here we do that with, respectively,
```sh  
cd momo-recite/frontend  
```  
```sh 
cd momo-recite/backend 
``` 

3. Seperately, in both backend and frontend folder, run
```sh 
npm install
``` 
This will install any dependencies required for our application.

4. Seperately, in both backend (first) and frontend (second) folder, run
```sh 
npm start 
``` 

This will start the backend and frontend server. A browser tab will be opened! You have a local version of the app running now! 
If you encounter an error like Ichido (one of the developers): "Attempted import error: 'startTransition' is not exported from 'react'...", try running:
```sh
npm install react@latest react-dom@latest
```
This should make it compile without errors. Alternatively, you can disregard the error messages in your browser and continue using the app. 

# Using the App 

Once you are on the local server, click Register to sign up for an account and Login once you've created one. Once you are in the app, go to the "Select Dictionary" page first to select a dictionay you want to learn. Then go to the "User" page to set your daily goals. Finally, go to the "Review" page to begin your studying journey! Once finished, you can easily logout by clicking the logout button on the "Logout" page, or simply close the browser.
